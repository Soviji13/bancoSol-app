// ==============================
// CONTROLADOR INCIDENCIAS
// ==============================

import {
  listarIncidencias,
  actualizarIncidencia
} from "./incidenciaApi.js";

import {
  mapearIncidenciaDesdeAPI,
  mapearIncidenciaConNuevoEstado
} from "./incidenciaMapper.js";

import {
  obtenerElementos,
  pintarIncidencias,
  marcarFilaSeleccionada,
  actualizarEstadoBotones,
  abrirPanelLateral,
  mostrarMensaje
} from "./incidenciaView.js";

// ==============================
// ELEMENTOS Y ESTADO
// ==============================

const elementos = {
  ...obtenerElementos(),

  panelFiltros: document.querySelector("#panel-filtros"),
  filtroReportadoPor: document.querySelector("#filtro-reportado-por"),
  filtroEstado: document.querySelector("#filtro-estado"),
  filtroCargo: document.querySelector("#filtro-cargo"),
  filtroAsunto: document.querySelector("#filtro-asunto"),
  btnAplicarFiltros: document.querySelector("#btn-aplicar-filtros"),
  btnLimpiarFiltros: document.querySelector("#btn-limpiar-filtros"),
  contadorFiltros: document.querySelector("#contador-filtros")
};

const estado = {
  filaSeleccionada: null,
  incidenciaSeleccionada: null,

  incidenciasOriginales: [],
  incidenciasFiltradas: [],

  filtros: {
    reportadoPor: "",
    estado: "",
    cargo: "",
    asunto: ""
  }
};

// ==============================
// INICIO
// ==============================

document.addEventListener("DOMContentLoaded", inicializarPagina);

function inicializarPagina() {
  registrarEventosSuperiores();
  registrarEventosFiltros();
  registrarEventosAcciones();

  actualizarBotones();
  cargarIncidencias();
}

// ==============================
// EVENTOS
// ==============================

function registrarEventosSuperiores() {
  if (elementos.botonFiltro) {
    elementos.botonFiltro.addEventListener("click", alternarPanelFiltros);
  }

  if (elementos.botonAyuda) {
    elementos.botonAyuda.addEventListener("click", () => {
      alert(
        "Pantalla de incidencias.\n\nSelecciona una fila para marcarla como leída o resuelta. Usa el filtro para buscar por responsable, estado, cargo o asunto."
      );
    });
  }
}

function registrarEventosFiltros() {
  if (elementos.btnAplicarFiltros) {
    elementos.btnAplicarFiltros.addEventListener("click", aplicarFiltrosDesdeFormulario);
  }

  if (elementos.btnLimpiarFiltros) {
    elementos.btnLimpiarFiltros.addEventListener("click", limpiarFiltros);
  }

  [
    elementos.filtroReportadoPor,
    elementos.filtroAsunto
  ].forEach((input) => {
    if (input) {
      input.addEventListener("keydown", aplicarFiltrosConEnter);
    }
  });

  [
    elementos.filtroEstado,
    elementos.filtroCargo
  ].forEach((select) => {
    if (select) {
      select.addEventListener("change", aplicarFiltrosDesdeFormulario);
    }
  });
}

function registrarEventosAcciones() {
  if (elementos.botonAnadir) {
    elementos.botonAnadir.addEventListener("click", () => {
      window.location.href = "formIncidencia.html";
    });
  }

  if (elementos.botonConfirmarLectura) {
    elementos.botonConfirmarLectura.addEventListener("click", confirmarLectura);
  }

  if (elementos.botonConfirmarResolucion) {
    elementos.botonConfirmarResolucion.addEventListener("click", confirmarResolucion);
  }
}

function aplicarFiltrosConEnter(evento) {
  if (evento.key === "Enter") {
    aplicarFiltrosDesdeFormulario();
  }
}

// ==============================
// CARGA
// ==============================

async function cargarIncidencias() {
  try {
    mostrarMensaje(elementos.mensaje, "Cargando incidencias...");

    const incidenciasAPI = await listarIncidencias();

    estado.incidenciasOriginales = incidenciasAPI.map((incidenciaAPI) => {
      return mapearIncidenciaDesdeAPI(incidenciaAPI);
    });

    estado.incidenciasFiltradas = [...estado.incidenciasOriginales];

    resetearSeleccion();
    actualizarContadorFiltros();
    pintarTablaActual();

    mostrarMensaje(elementos.mensaje, "");
  } catch (error) {
    console.error(error);
    mostrarMensaje(elementos.mensaje, "No se han podido cargar las incidencias.");
  }
}

function pintarTablaActual() {
  pintarIncidencias({
    cuerpoTabla: elementos.cuerpoTabla,
    incidencias: estado.incidenciasFiltradas,
    onSeleccionarFila: seleccionarFila,
    onDobleClickFila: abrirPanelLateral
  });
}

// ==============================
// SELECCIÓN
// ==============================

function seleccionarFila(fila, incidencia) {
  marcarFilaSeleccionada(elementos.cuerpoTabla, fila);

  estado.filaSeleccionada = fila;
  estado.incidenciaSeleccionada = incidencia;

  actualizarBotones();
  abrirPanelLateral(incidencia);
}

function resetearSeleccion() {
  estado.filaSeleccionada = null;
  estado.incidenciaSeleccionada = null;
  actualizarBotones();
}

function actualizarBotones() {
  actualizarEstadoBotones({
    botonConfirmarLectura: elementos.botonConfirmarLectura,
    botonConfirmarResolucion: elementos.botonConfirmarResolucion,
    incidenciaSeleccionada: estado.incidenciaSeleccionada
  });
}

// ==============================
// ACCIONES DE ESTADO
// ==============================

async function confirmarLectura() {
  await cambiarEstadoSeleccionada("LEIDA");
}

async function confirmarResolucion() {
  await cambiarEstadoSeleccionada("RESUELTA");
}

async function cambiarEstadoSeleccionada(nuevoEstado) {
  if (!estado.incidenciaSeleccionada) {
    alert("Debes seleccionar primero una incidencia.");
    return;
  }

  try {
    const incidenciaActualizada = mapearIncidenciaConNuevoEstado(
      estado.incidenciaSeleccionada,
      nuevoEstado
    );

    await actualizarIncidencia(
      estado.incidenciaSeleccionada.id,
      incidenciaActualizada
    );

    await cargarIncidencias();
  } catch (error) {
    console.error(error);
    alert("No se ha podido actualizar el estado de la incidencia.");
  }
}

// ==============================
// FILTROS
// ==============================

function alternarPanelFiltros() {
  if (!elementos.panelFiltros) {
    return;
  }

  elementos.panelFiltros.classList.toggle("panel-filtros--oculto");
}

function aplicarFiltrosDesdeFormulario() {
  estado.filtros = {
    reportadoPor: elementos.filtroReportadoPor?.value.trim() ?? "",
    estado: elementos.filtroEstado?.value ?? "",
    cargo: elementos.filtroCargo?.value ?? "",
    asunto: elementos.filtroAsunto?.value.trim() ?? ""
  };

  estado.incidenciasFiltradas = filtrarIncidencias(
    estado.incidenciasOriginales,
    estado.filtros
  );

  resetearSeleccion();
  actualizarContadorFiltros();
  pintarTablaActual();
}

function filtrarIncidencias(incidencias, filtros) {
  return incidencias.filter((incidencia) => {
    return cumpleFiltroReportadoPor(incidencia, filtros.reportadoPor)
      && cumpleFiltroEstado(incidencia, filtros.estado)
      && cumpleFiltroCargo(incidencia, filtros.cargo)
      && cumpleFiltroAsunto(incidencia, filtros.asunto);
  });
}

function cumpleFiltroReportadoPor(incidencia, texto) {
  if (!texto) {
    return true;
  }

  return normalizarTexto(incidencia.reportadoPorNombre).includes(
    normalizarTexto(texto)
  );
}

function cumpleFiltroEstado(incidencia, estadoFiltro) {
  if (!estadoFiltro) {
    return true;
  }

  return incidencia.estado === estadoFiltro;
}

function cumpleFiltroCargo(incidencia, cargoFiltro) {
  if (!cargoFiltro) {
    return true;
  }

  return incidencia.reportadoPorTipo === cargoFiltro;
}

function cumpleFiltroAsunto(incidencia, texto) {
  if (!texto) {
    return true;
  }

  return normalizarTexto(incidencia.asunto).includes(
    normalizarTexto(texto)
  );
}

function limpiarFiltros() {
  if (elementos.filtroReportadoPor) {
    elementos.filtroReportadoPor.value = "";
  }

  if (elementos.filtroEstado) {
    elementos.filtroEstado.value = "";
  }

  if (elementos.filtroCargo) {
    elementos.filtroCargo.value = "";
  }

  if (elementos.filtroAsunto) {
    elementos.filtroAsunto.value = "";
  }

  estado.filtros = {
    reportadoPor: "",
    estado: "",
    cargo: "",
    asunto: ""
  };

  estado.incidenciasFiltradas = [...estado.incidenciasOriginales];

  resetearSeleccion();
  actualizarContadorFiltros();
  pintarTablaActual();
}

function actualizarContadorFiltros() {
  if (!elementos.contadorFiltros) {
    return;
  }

  const total = contarFiltrosActivos();

  elementos.contadorFiltros.textContent = String(total);
  elementos.contadorFiltros.hidden = total === 0;
}

function contarFiltrosActivos() {
  let total = 0;

  if (estado.filtros.reportadoPor) {
    total++;
  }

  if (estado.filtros.estado) {
    total++;
  }

  if (estado.filtros.cargo) {
    total++;
  }

  if (estado.filtros.asunto) {
    total++;
  }

  return total;
}

// ==============================
// UTILIDADES
// ==============================

function normalizarTexto(texto) {
  return String(texto ?? "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}