package com.bancosol.dao;

import com.bancosol.entities.Contacto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ContactoRepository extends JpaRepository<Contacto, Long> {

    Optional<Contacto> findByEmail(String email);

    Optional<Contacto> findByTelefono(String telefono);
}