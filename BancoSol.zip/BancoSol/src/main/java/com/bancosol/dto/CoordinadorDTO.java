package com.bancosol.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoordinadorDTO {

    private Long id;

    private String nombre;

    private String zonaGeografica;

    private Short numeroTiendas;

    private Boolean permisoModificar;

    private Long usuarioId;

    private ContactoDTO contacto;

    private List<CampaniaDTO> campanias;
}