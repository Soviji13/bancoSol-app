import { apiService } from './apiService.js';
import { canalComunicacion } from './utils.js';

// Estado local de este componente
// Registra el ID de la campaña que el usuario tiene seleccionada para ver en ese instante
let idCampaniaVisualizada = 1; 

// Cuando el DOM estático y los scripts del selector estén totalmente listos:
document.addEventListener('DOMContentLoaded', () => {
    // Localizamos los botones de control para abrir y cerrar el modal selector del HTML
    const btnSeleccionarCampania = document.querySelector('.cambiar-campania button');
    const btnCerrarSelector = document.getElementById('cerrar-selector');

    // Si los elementos existen en la página, les asociamos sus respectivos disparadores para controlar el modal
    if (btnSeleccionarCampania) btnSeleccionarCampania.onclick = abrirSelectorCampanias;
    if (btnCerrarSelector) btnCerrarSelector.onclick = () => document.getElementById('modal-campanias').style.display = 'none';
});

// selectorCampanias.js -> Reemplaza la función abrirSelectorCampanias
// Función asíncrona para descargar las campañas desde el servicio y pintar las tarjetas interactivas
async function abrirSelectorCampanias() {
    try {
        // Pedimos las campañas al servicio
        // Lanzamos la petición asíncrona para traernos el catálogo completo actualizado de campañas de la API
        const campanias = await apiService.obtenerCampanias();

        // SINCRONIZACIÓN: Leemos la memoria RAM externa antes de pintar las tarjetas
        // Comprobamos si el navegador ya recuerda alguna campaña visualizada previamente para dejarla marcada por defecto
        const guardada = localStorage.getItem("idCampaniaVisualizada");
        if (guardada) {
            idCampaniaVisualizada = parseInt(guardada);
        } else if (campanias.length > 0) {
            // Si el historial está limpio, buscamos la campaña que venga marcada como activa en el servidor o agarramos la primera de la lista
            const campaniaActiva = campanias.find(c => c.activa === true) || campanias[0];
            idCampaniaVisualizada = campaniaActiva.id;
        }

        // Recuperamos el contenedor del grid y lo vaciamos por completo para evitar que se dupliquen tarjetas si el usuario lo abre varias veces
        const grid = document.getElementById('lista-campanias');
        grid.innerHTML = ''; 
        
        // Desplegamos visualmente el modal usando flex para centrar los elementos interiores en pantalla
        document.getElementById('modal-campanias').style.display = 'flex';

        // Iteramos el catálogo de campañas recuperado para fabricar dinámicamente cada una de las tarjetas interactivas
        campanias.forEach(c => {
            // Evaluamos si el ID de la campaña coincide exactamente con la que el usuario está consultando ahora mismo
            const esSeleccionada = c.id === idCampaniaVisualizada;
            
            // Creamos un nodo div de forma dinámica y le inyectamos las clases CSS pertinentes en función de sus estados de actividad
            const card = document.createElement('div');
            card.className = `campania-card ${esSeleccionada ? 'seleccionada' : ''} ${c.activa ? 'es-activa' : 'es-inactiva'}`;
            
            // Saneamos y formateamos los objetos de fecha de la API pasándolos a cadenas legibles con formato local (DD/MM/AAAA)
            const inicio = new Date(c.fechaInicio).toLocaleDateString();
            const fin = new Date(c.fechaFin).toLocaleDateString();
            
            // INYECTAMOS INLINE EL SEGURO CONTRA ROTURAS (white-space: nowrap)
            // Fabricamos los fragmentos HTML de los badges aplicando estilos inline estrictos para impedir que el texto se parta en bloques feos
            const labelActiva = c.activa 
                ? '<span class="badge badge-activa" style="white-space: nowrap; display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold;">ACTIVA</span>' 
                : '<span class="badge badge-inactiva" style="white-space: nowrap; display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold;">INACTIVA</span>';
            
            // Si es la campaña que coincide con la selección activa, le preparamos la etiqueta de acompañamiento visual
            const labelSeleccionada = esSeleccionada 
                ? '<span class="badge badge-viendo" style="white-space: nowrap; display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; margin-left: 5px;">VIENDO AHORA</span>' 
                : '';

            // Maquetamos la cabecera interna con un flex dinámico que respeta el espacio de los badges
            card.innerHTML = `
                <div class="card-header-flex" style="display: flex; justify-content: space-between; align-items: center; width: 100%; gap: 10px; margin-bottom: 8px;">
                    <h3 style="margin: 0; font-size: 1.1em; color: #1e3a8a; text-align: left;">${c.nombre}</h3>
                    <div class="badges-container" style="display: flex; align-items: center; flex-shrink: 0;">
                        ${labelActiva}
                        ${labelSeleccionada}
                    </div>
                </div>
                <p><strong>Inicio:</strong> ${inicio} | <strong>Fin:</strong> ${fin}</p>
                <p class="anio-info" style="margin-top: 5px; font-size: 0.85em; color: #64748b;">Año fiscal: ${c.anio}</p>
            `;

            // Vinculamos el clic sobre la tarjeta para actualizar el estado local y ejecutar el procesamiento del cambio
            card.onclick = () => {
                idCampaniaVisualizada = c.id; 
                seleccionarCampania(c);
            };
            
            // Adjuntamos la tarjeta terminada y lista para usarse como un nodo hijo directo dentro de nuestro grid modal
            grid.appendChild(card);
        });
    } catch (error) {
        console.error("Error en el selector de campañas:", error);
    }
}

// selectorCampanias.js -> Nueva función final
// Se encarga de cerrar de forma limpia el modal y coordinar la sincronización del cambio de campaña con el resto de scripts de la app
function seleccionarCampania(campania) {
    // Escondemos el modal del selector de la interfaz retirando su propiedad flex
    document.getElementById('modal-campanias').style.display = 'none';
    
    // PUENTE DIRECTO: Si estamos en la misma ventana, llamamos al método manual inmediatamente
    // Verificamos de forma segura si el script de la tabla expuso su función global de recarga manual en el objeto window
    if (typeof window.cambiarCampaniaManual === 'function') {
        window.cambiarCampaniaManual(campania);
    }
    
    // Mantenemos el mensaje por si otros frames externos (como los filtros) están a la escucha
    // Publicamos un mensaje estructurado por nuestro canal BroadcastChannel para alertar a cualquier iframe o pestaña vecina del cambio
    canalComunicacion.postMessage({ 
        type: 'cambiar-campania', 
        campania: campania 
    });
}