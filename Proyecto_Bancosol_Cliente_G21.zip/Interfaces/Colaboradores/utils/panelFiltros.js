// Importamos la capa de servicios de la API y el canal de radio compartido para enviar mensajes entre componentes
import { apiService } from './apiService.js';
import { canalComunicacion } from './utils.js';

// Cuando el DOM estático y los scripts del panel de filtros estén completamente listos:
document.addEventListener('DOMContentLoaded', async () => {
    
    // Cargamos de forma asíncrona los datos maestros que rellenarán los selectores (como las localidades)
    await cargarFiltrosMaestros();

    // Vinculamos el evento clic del botón "Aplicar" para que ejecute la extracción y envío de filtros
    document.getElementById('btn-aplicar-filtros').onclick = enviarFiltros;
    
    // Vinculamos el botón "Limpiar" para restablecer todos los controles a su estado inicial
    document.getElementById('btn-limpiar-filtros').onclick = limpiarFiltros;
    
    // Intentamos localizar el botón de cierre del panel de filtros
    const btnCerrar = document.getElementById('btn-cerrar-filtros');
    if (btnCerrar) 
    {
        // Si el botón existe en el HTML, le asignamos la función de restaurar el menú lateral original
        btnCerrar.onclick = cerrarPanel;
    }
});

// Función asíncrona encargada de extraer las localidades de la caché y sincronizar los estados previos de los elementos
async function cargarFiltrosMaestros() 
{
    // Recuperamos la caché de colaboradores guardada en sessionStorage (si no hay nada, inicializamos con un array vacío)
    const datosColabs = JSON.parse(sessionStorage.getItem("colaboradoresCache")) || [];
    
    // Obtenemos el elemento select del HTML destinado a las localidades
    const selectLoc = document.getElementById('filtro-localidad');
    
    // Extraemos un array limpio, sin duplicados (usando Set), filtrando nulos/vacíos y ordenado alfabéticamente (.sort)
    const localidades = [...new Set(datosColabs.map(c => c.localidadNombre))].filter(Boolean).sort();
    
    // Iteramos la lista final de localidades saneadas y las añadimos como opciones reales al elemento select
    localidades.forEach(loc => {
        selectLoc.add(new Option(loc, loc));
    });

    // Sincronizamos el estado del checkbox si la vista agrupada "Todas las campañas" estaba guardada en memoria del navegador
    const mostrarTodasAlInicio = localStorage.getItem("mostrarTodasCampanias") === "true";
    const checkTodas = document.getElementById('filtro-todas-campanias');
    
    // Si el checkbox existe, lo dejamos marcado o desmarcado según el historial de navegación del usuario
    if (checkTodas) 
    {
        checkTodas.checked = mostrarTodasAlInicio;
    }
}

// Recopila los valores de la interfaz, monta el contrato de filtros y los manda al exterior
function enviarFiltros(e) {
    // Si la función fue disparada por un evento nativo de formulario, anulamos su comportamiento para evitar recargas
    if (e && typeof e.preventDefault === 'function') 
    {
        e.preventDefault();
    }

    // 🌟 ENVIAMOS EL CONTRATO CORRECTO: f.todasCampanias como boolean
    // Construimos el objeto literal con el estado exacto de cada input y checkbox del panel
    const filtros = {
        // Al nombre de la tienda le quitamos espacios muertos y lo forzamos a mayúsculas para evitar fallos de coincidencia
        tienda: document.getElementById('filtro-tienda').value.trim().toUpperCase(),
        localidad: document.getElementById('filtro-localidad').value,
        todasCampanias: document.getElementById('filtro-todas-campanias').checked, 
        soloCapital: document.getElementById('filtro-capital').checked,
        soloActiva: document.getElementById('filtro-activa').checked
    };

    // Publicamos el objeto a través de BroadcastChannel para que 'conexionApiTabla.js' lo cace al vuelo y actualice las filas
    canalComunicacion.postMessage({ type: 'aplicar-filtros', filtros });
}

// Borra el contenido de todos los elementos de selección y resetea la tabla origen
function limpiarFiltros(e) 
{
    // Frenamos la propagación o comportamiento por defecto del evento si es necesario
    if (e && typeof e.preventDefault === 'function') e.preventDefault();
    
    // Devolvemos los inputs de texto a cadenas vacías
    document.getElementById('filtro-tienda').value = '';
    document.getElementById('filtro-localidad').value = '';
    
    // Desmarcamos de forma absoluta todos los checkboxes de control del panel
    document.getElementById('filtro-todas-campanias').checked = false;
    document.getElementById('filtro-capital').checked = false;
    document.getElementById('filtro-activa').checked = false;
    
    // Invocamos la función de enviar filtros para propagar el estado limpio y que la tabla muestre todo de nuevo
    enviarFiltros();
}

// Gestiona la salida del panel de filtros restaurando el estado original de la barra de navegación
function cerrarPanel() 
{
    // Validamos de forma segura si nos encontramos corriendo dentro de un entorno con ventana padre (iframe)
    if (window.parent) 
    {
        // Buscamos el elemento contenedor del iframe del menú lateral en el árbol de nodos del padre
        const iframeMenu = window.parent.document.querySelector('.menu-lateral-iframe');
        
        // Si lo localizamos, cambiamos su origen (src) para reestablecer la vista por defecto del menú de navegación
        if (iframeMenu) iframeMenu.src = '../MenuLateral/menu-lateral.html';
    }
}