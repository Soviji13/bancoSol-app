import { apiService } from './apiService.js';

// VARIABLES GLOBALES
let contadorResponsables = 0; // Lleva la cuenta de cuántos responsables hemos añadido para asignarles un ID y número único en la interfaz
let mapaGeografico = []; // Almacenará la relación cruzada de CPs, localidades y zonas para el autocompletado inteligente de la dirección

// Cuando el DOM estático y todos los scripts estén completamente cargados e inicializados:
document.addEventListener('DOMContentLoaded', () => {
    // Inicializamos la carga de las opciones de registro por si hiciera falta pre-cargar catálogos
    cargarOpcionesRegistro();

    // 1. Escuchar cambio de CP
    // Cada vez que el usuario modifique o seleccione el código postal, disparamos la función de autocompletado inteligente
    const inputCP = document.querySelector('select[name="numeroCP"]');
    if (inputCP) inputCP.addEventListener('change', manejarAutocompletadoCP);

    // 2. Escuchar el checkbox de Capital
    // Si el usuario marca o desmarca que la entidad está en la capital, conmutamos la visibilidad del campo de distrito
    const checkCapital = document.getElementById('check-es-capital');
    if (checkCapital) 
    {
        checkCapital.addEventListener('change', function() 
        {
            toggleDistrito(this);
        });
    }

    // 3. Botón Abrir Registro
    // Al hacer clic en el botón de dar de alta, ocultamos el listado plano de la tabla y desplegamos el formulario completo
    const btnAbrir = document.getElementById('btn-abrir-registro');
    if (btnAbrir) 
    {
        btnAbrir.onclick = () => {
            const contenedorTabla = document.querySelector('.contenedor-tabla-scroll');
            const modal = document.getElementById('modal-registro');
            const avisoBorrado = document.getElementById('aviso-borrado');

            // Escondemos temporalmente la tabla principal y los banners de borrado para dejar espacio limpio al formulario
            if (contenedorTabla) contenedorTabla.style.display = 'none';
            if (avisoBorrado) avisoBorrado.style.display = 'none';

            // Ocultamos el pie de página para que no flote de forma extraña en pantallas pequeñas
            document.querySelector('.pie-pagina').style.display = 'none';

            // Activamos la clase de sustitución de vista y forzamos el display block del contenedor modal
            modal.classList.add('v-sustitucion');
            modal.style.display = 'block';

            // Volvemos a sincronizar los datos maestros de las listas desplegables por seguridad
            cargarOpcionesRegistro(); 
            
            // Si el usuario entra y no tiene ningún bloque de contacto pintado, le inyectamos el primero automáticamente para ahorrarle un clic
            const contenedor = document.getElementById('contenedor-responsables');
            if (contenedor.children.length === 0) agregarBloqueResponsable();
            
            // Forzamos el scroll de la ventana arriba del todo para que empiece a rellenar cómodamente
            window.scrollTo(0, 0);
        };
    }
});

// Función para volver a la tabla
// Restaura la interfaz ocultando el formulario de registro y volviendo a hacer visible el listado principal con su footer
function cerrarModalRegistro() 
{
    const contenedorTabla = document.querySelector('.contenedor-tabla-scroll');
    const modal = document.getElementById('modal-registro');

    // Ocultamos el modal de registro y limpiamos sus clases de estado
    modal.style.display = 'none';
    modal.classList.remove('v-sustitucion');

    // Volvemos a habilitar la visibilidad de la tabla de colaboradores original
    if (contenedorTabla) contenedorTabla.style.display = 'block';

    // Restauramos el pie de página de la aplicación
    document.querySelector('.pie-pagina').style.display = 'flex';
}
// La exponemos a window por si se llama desde un botón HTML con onclick
window.cerrarModalRegistro = cerrarModalRegistro;

// Se encarga de descargar en paralelo todos los datos maestros de la API y montar los datalists y el mapa de autocompletado
async function cargarOpcionesRegistro() 
{
    try 
    {
        // Lanzamos todas las peticiones asíncronas juntas con un Promise.all para optimizar el rendimiento de la red
        const [resTiendas, resCampanias, resCps, resLocs, resDirs, resDists, resCoords, resZonas] = await Promise.all([
            apiService.obtenerTiendas(),
            apiService.obtenerCampanias(),
            apiService.obtenerCodigosPostales(),
            apiService.obtenerLocalidades(),
            apiService.obtenerDirecciones(),
            apiService.obtenerDistritos(),
            apiService.obtenerCoordinadores(),
            apiService.obtenerZonasGeograficas()
        ]);

        // Llenar datalists
        // Inyectamos las etiquetas option correspondientes dentro de cada lista de sugerencias dinámicas del HTML
        document.getElementById('lista-localidades').innerHTML = '<option value="">Localidad...</option>' + resLocs.map(l => `<option value="${l.nombre}">${l.nombre}</option>`).join('');
        document.getElementById('lista-cps').innerHTML = '<option value="">CP...</option>' + resCps.map(cp => `<option value="${cp.codigo}">${cp.codigo}</option>`).join('');
        document.getElementById('lista-distritos').innerHTML = '<option value="">Nombre del Distrito...</option>' + resDists.map(d => `<option value="${d.nombre}">${d.nombre}</option>`).join('');
        document.getElementById('lista-zonas').innerHTML = '<option value="">Zona Geográfica...</option>' + resZonas.map(z => `<option value="${z.nombre}">${z.nombre}</option>`).join('');

        // Campañas
        // Recuperamos el panel del DOM destinado a albergar las campañas y sus subtiendas asociadas
        const contCampaniasReg = document.getElementById('check-campanias');
        
        // Aplicamos maquetación limpia inline para estructurar las tarjetas de campaña en formato de columna ordenada
        contCampaniasReg.style.display = 'flex';
        contCampaniasReg.style.flexDirection = 'column';
        contCampaniasReg.style.width = '100%';
        contCampaniasReg.style.gap = '12px';
        contCampaniasReg.style.boxSizing = 'border-box';

        // Mapeamos el catálogo de campañas de la API construyendo la interfaz de cada bloque: checkbox maestro y subpanel de tiendas
        contCampaniasReg.innerHTML = resCampanias.map(c => `
            <div class="campania-block-item" style="width: 100%; box-sizing: border-box; background: #f8fafc; padding: 12px; border-radius: 6px; border: 1px solid #e2e8f0; display: block;">
                <label style="font-weight: bold; color: var(--color-principal); cursor: pointer; display: flex; align-items: center; gap: 10px; width: 100%; box-sizing: border-box;">
                    <input type="checkbox" value="${c.id}" class="check-campania-master" onchange="toggleTiendasCampania(this, ${c.id})" style="flex-shrink: 0; width: 16px; height: 16px; margin: 0;">
                    <span style="line-height: 1.4; flex: 1; white-space: normal; text-align: left; word-break: break-word; font-size: 1.05em;">${c.nombre}</span>
                </label>
                
                <div id="tiendas-campania-${c.id}" style="display: none; margin-left: 20px; border-left: 2px solid #cbd5e1; padding-left: 14px; margin-top: 10px; width: calc(100% - 20px); box-sizing: border-box; max-height: 200px; overflow-y: auto;">
                    <span style="font-size: 0.85em; color: #64748b; margin-bottom: 8px; display: block; font-weight: 500; text-align: left;">Selecciona las tiendas asignadas para esta campaña:</span>
                    ${resTiendas.filter(t => c.idsTiendas && c.idsTiendas.includes(t.id)).map(t => `
                        <label style="display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px; font-size: 0.9em; cursor: pointer; color: #334155; width: 100%; box-sizing: border-box;">
                            <input type="checkbox" value="${t.id}" class="check-tienda-sub" style="margin-top: 3px; flex-shrink: 0; width: 14px; height: 14px; margin-left: 0;">
                            <span style="flex: 1; white-space: normal; text-align: left; line-height: 1.3; word-break: break-word;">${t.nombre}</span>
                        </label>
                    `).join('')}
                </div>
            </div>
        `).join('');

        // Exponemos la función al HTML
        // Altera el display del subpanel de tiendas subordinado en base a si la campaña maestra está seleccionada o no
        window.toggleTiendasCampania = function(checkbox, campId) {
            const div = document.getElementById(`tiendas-campania-${campId}`);
            if (div) div.style.display = checkbox.checked ? 'block' : 'none';
            // Si desmarca la campaña, limpiamos en cadena los checks de sus tiendas para prevenir envíos residuales corruptos
            if (!checkbox.checked) div.querySelectorAll('input').forEach(i => i.checked = false);
        };

        // CONSTRUCCIÓN DEL MAPA INTELIGENTE
        // Cruzamos las direcciones con CPs, localidades, zonas y distritos para fabricar un índice relacional rápido en memoria
        mapaGeografico = resDirs.map(dir => {
            const cpObj = resCps.find(c => c.id === dir.codigoPostalId);
            const locObj = resLocs.find(l => l.id === dir.localidadId);
            const zonaObj = locObj ? resZonas.find(z => z.id === locObj.zonaGeoId) : null;
            const distObj = resDists.find(d => d.id === dir.distritoId);
            
            return {
                codigo: cpObj ? cpObj.codigo : null,
                localidad: locObj ? locObj.nombre : '',
                zonaNombre: zonaObj ? zonaObj.nombre : '', 
                distrito: distObj ? distObj.nombre : '',
                esCapital: dir.esCapital
            };
        }).filter(item => item.codigo); // Saneamos el mapa descartando registros huerfanos que carezcan de código postal

        // Rellenamos el selector de coordinadores asegurando una primera opción neutra de invitación
        const selectCoords = document.getElementById('select-coordinadores');
        selectCoords.innerHTML = '<option value="">Seleccione un coordinador...</option>' + 
            resCoords.map(c => `<option value="${c.id}">${c.nombre}</option>`).join('');

    } 
    catch (error) 
    {
        console.error("Error cargando el motor:", error);
    }
}

// Conmuta la visibilidad del bloque del distrito dependiendo de si el checkbox de capital está marcado o vacío
function toggleDistrito(checkbox) 
{
    const divDistrito = document.getElementById('campo-distrito');
    if (divDistrito) {
        // Mostramos si está activo, escondemos si está apagado
        divDistrito.style.display = checkbox.checked ? 'block' : 'none';
        // Si el usuario desmarca la opción, limpiamos el select interno para evitar mandar un distrito residual inválido
        if (!checkbox.checked) divDistrito.querySelector('select').value = '';
    }
}
window.toggleDistrito = toggleDistrito;

// Se dispara al modificar el campo CP. Escanea el mapa relacional en caché y autocompleta el formulario al vuelo si hay coincidencia
function manejarAutocompletadoCP(e) 
{
    const cpIntroducido = e.target.value;
    // Buscamos si el string numérico del CP introducido calza con alguna clave indexada de nuestro mapa geográfico
    const coincidencia = mapaGeografico.find(m => m.codigo == cpIntroducido);

    // Si localizamos los datos maestros de ese CP, automatizamos la escritura en el formulario
    if (coincidencia) 
    {
        document.querySelector('select[name="nombreLocalidad"]').value = coincidencia.localidad;
        const checkCapital = document.getElementById('check-es-capital');
        checkCapital.checked = coincidencia.esCapital;
        
        // Refrescamos la visibilidad del panel de distritos según el flag de capital recuperado
        toggleDistrito(checkCapital);

        // Si la coincidencia indica que es capital y viene con el distrito pre-asignado, lo escribimos directamente
        if (coincidencia.esCapital && coincidencia.distrito) {
            document.querySelector('select[name="nombreDistrito"]').value = coincidencia.distrito;
        }

        // Si existe zona geográfica vinculada, auto-rellenamos el campo, lo bloqueamos en modo lectura y lo sombreamos en gris estético
        const inputZona = document.querySelector('select[name="nombreZonaGeografica"]');
        if (coincidencia.zonaNombre) {
            inputZona.value = coincidencia.zonaNombre;
            inputZona.disabled = true; 
            inputZona.style.backgroundColor = "#e9ecef"; // Color clásico grisáceo de campo bloqueado
        } else {
            // Si no hay zona mapeada, liberamos el campo dándole fondo blanco para que el usuario la declare manualmente
            inputZona.value = "";
            inputZona.disabled = false;
            inputZona.style.backgroundColor = "#fff";
        }
    }
}

// Fabrica e inyecta dinámicamente un bloque HTML completo de tarjeta para añadir datos y credenciales de un responsable de entidad
function agregarBloqueResponsable() {
    const contenedor = document.getElementById('contenedor-responsables');
    // Guardamos el índice actual del contador y después lo incrementamos para la siguiente iteración
    const index = contadorResponsables++;
    
    // Diseñamos el esqueleto de la tarjeta asignando selectores de clases y IDs únicos controlados para leer sus valores al enviar
    const html = `
        <div class="responsable-card" id="resp-${index}">
            <div class="card-header">
                <h4>Responsable #${index + 1}</h4>
                <button type="button" class="btn-eliminar-resp" onclick="this.closest('.responsable-card').remove()">Eliminar</button>
            </div>
            <div class="form-grid-resp">
                <input type="text" placeholder="Nombre completo" class="r-nombre" required>
                <input type="email" placeholder="Email" class="r-email" required>
                <input type="tel" placeholder="Teléfono" class="r-telefono" required>
                <div class="radio-group">
                    <label><input type="radio" name="esPrincipal" class="r-principal" ${index === 0 ? 'checked' : ''}> ¿Principal?</label>
                </div>
                <hr>
                <input type="text" placeholder="Username (Email)" class="r-user" required>
                <input type="password" placeholder="Contraseña" class="r-pass" required>
            </div>
        </div>
    `;
    // Adjuntamos la nueva estructura de responsable justo al final del contenedor dinámico
    contenedor.insertAdjacentHTML('beforeend', html);
}
// La exponemos a window por si tienes un botón de "Añadir Responsable" con onclick en el HTML
window.agregarBloqueResponsable = agregarBloqueResponsable;

// Intercepta el submit definitivo del registro, consolida las colecciones complejas y lanza la persistencia hacia la API
document.getElementById('form-registro-entidad').addEventListener('submit', async (e) => {
    // Frenamos la propagación y recarga nativa del formulario para gestionar el proceso de forma asíncrona mediante JS
    e.preventDefault();
    
    try 
    {
        // Habilitamos todos los selects temporalmente para que FormData pueda recoger sus valores
        document.querySelectorAll('select:disabled').forEach(select => {
            select.dataset.wasDisabled = 'true';
            select.disabled = false;
        });

        // Inicializamos la lectura directa de los campos clave del formulario base
        const formData = new FormData(e.target);

        // Volvemos a deshabilitar los selects que estaban deshabilitados
        document.querySelectorAll('select[data-was-disabled="true"]').forEach(select => {
            select.disabled = true;
            delete select.dataset.wasDisabled;
        });
        
        // Procesamos todas las tarjetas de responsables pintadas, extrayendo sus valores para armar el array estructurado
        const responsables = Array.from(document.querySelectorAll('.responsable-card')).map(card => ({
            nombre: card.querySelector('.r-nombre').value,
            email: card.querySelector('.r-email').value,
            telefono: card.querySelector('.r-telefono').value,
            esPrincipal: card.querySelector('.r-principal').checked,
            username: card.querySelector('.r-user').value,
            password: card.querySelector('.r-pass').value
        }));

        // Inicializamos las estructuras destinadas a consolidar la relación jerárquica de campañas y subtiendas
        const idsCampanias = [];
        const tiendasPorCampania = {};
        
        // Extraemos la información de forma jerárquica estricta inspeccionando solo los bloques de campaña seleccionados
        document.querySelectorAll('.check-campania-master:checked').forEach(cb => {
            const cId = parseInt(cb.value);
            // Consolidamos el ID de la campaña en nuestra lista plana
            idsCampanias.push(cId);
            
            // Localizamos en exclusiva las tiendas marcadas que vivan dentro del bloque DOM de esta campaña concreta
            const checksTiendas = document.querySelectorAll(`#tiendas-campania-${cId} .check-tienda-sub:checked`);
            // Mapeamos los nodos pasándolos a un array de IDs enteros bajo la clave de la campaña correspondiente
            tiendasPorCampania[cId] = Array.from(checksTiendas).map(t => parseInt(t.value));
        });

        // Consolidamos el payload final (objeto de actualización) normalizando tipos de datos y mapeando las listas jerárquicas procesadas
        const objetoFinal = {
            nombre: formData.get('nombre'),
            estadoActivo: formData.get('estadoActivo') === 'on',
            observaciones: formData.get('observaciones'),
            calle: formData.get('calle'),
            numero: parseInt(formData.get('numero')),
            esCapital: formData.get('esCapital') === 'on',
            nombreLocalidad: formData.get('nombreLocalidad'),
            numeroCP: formData.get('numeroCP'),
            nombreZonaGeografica: formData.get('nombreZonaGeografica'),
            nombreDistrito: formData.get('nombreDistrito') || null,
            responsables: responsables,
            idsCampanias: idsCampanias,             
            tiendasPorCampania: tiendasPorCampania, 
            idCoordinador: parseInt(formData.get('idCoordinador'))
        };

        // Envío limpio a través del servicio
        // Despachamos el payload consolidado invocando el servicio de inserción de la API
        await apiService.crearEntidad(objetoFinal);
        alert("¡Entidad creada con éxito!");
        
        // Si el servidor responde de forma exitosa, forzamos un reload completo de la ventana para regresar al flujo base actualizado
        window.location.reload();

    } 
    catch (error) 
    {
        console.error("Fallo crítico:", error);
        
        // Captura y aislamiento de excepciones de negocio controladas procedentes de restricciones de la base de datos
        if (error.message && error.message.includes("dirección a la que la has asociado ya existe")) 
        {
            alert("No puedes añadir esta entidad colaboradora porque la dirección a la que la has asociado ya existe");
        } 
        else if (error.message && (error.message.includes("Este teléfono ya está asociado") || error.message.includes("Contacto_telefono_key"))) 
        {
            // CAZAMOS EL ERROR DE TELÉFONO DUPLICADO
            alert("Este teléfono ya está asociado a otro usuario");
        } else 
        {
            // Notificación de alerta por si salta un error imprevisto ajeno a las reglas de negocio anteriores
            alert("Error al guardar: " + error.message);
        }
    }
});

// Función utilitaria encargada de extraer y parsear a enteros los valores de los checkboxes marcados dentro de un contenedor específico
function obtenerChecksMarcados(idContenedor) 
{
    const contenedor = document.getElementById(idContenedor);
    // Si por algún motivo el ID del contenedor no devuelve ningún elemento, abortamos devolviendo un array vacío por seguridad
    if (!contenedor) return [];
    
    // Capturamos la colección de checkboxes marcados (:checked) en su interior
    const checks = contenedor.querySelectorAll('input[type="checkbox"]:checked');
    // Transformamos la lista de nodos en un array nativo y convertimos cada valor en formato numérico entero
    return Array.from(checks).map(cb => parseInt(cb.value));
}