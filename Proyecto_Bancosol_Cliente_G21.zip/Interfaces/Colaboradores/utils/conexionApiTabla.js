// utils/conexionApiTabla.js
import { apiService } from './apiService.js';
import { canalComunicacion, toggleLoader } from './utils.js';

// VARIABLES GLOBALES Y CACHÉ

let colaboradoresCache = [];        // Almacena los colaboradores filtrados actuales que se están mostrando en pantalla
let colaboradoresOriginales = [];   // Copia intacta de todos los colaboradores traídos de la API (para no perder datos al filtrar)
let campaniasCache = [];            // Guarda el listado de todas las campañas maestras disponibles
let modoEliminarActivo = false;     // Flag para controlar si el usuario ha pulsado el botón de borrar y está en modo "peligro"
let idCampaniaVisualizada = 1;      // ID de la campaña de la que estamos mostrando los datos actualmente (por defecto 1)
let idColaboradorActivo = null;     // ID del colaborador que el usuario ha seleccionado al hacer doble clic

// MEMORIA DE FILTROS: Estructura base para persistir la búsqueda entre recargas de campaña
let filtrosActivos = {
    tienda: "",
    localidad: "",
    todasCampanias: false,
    soloCapital: false,
    soloActiva: false
};

// Cuando el DOM y los scripts estén completamente cargados e inicializados:
document.addEventListener('DOMContentLoaded', () => {
    
    // Lanzamos la carga inicial de los datos de la API para pintar la tabla por primera vez
    cargarTablaDinamica();

    // Accedemos a los elementos clave del DOM que vamos a necesitar para interactuar
    const tbody = document.querySelector('#tabla-body');
    const btnEliminar = document.getElementById('btn-eliminar-colaborador');
    const aviso = document.getElementById('aviso-borrado');
    const tabla = document.querySelector('table');

    // Escuchamos el DOBLE CLIC en el cuerpo de la tabla para abrir el detalle de un colaborador
    tbody.addEventListener('click', (event) => {
        // Buscamos la fila (tr) más cercana al elemento donde se hizo clic
        const fila = event.target.closest('tr');
        
        // Si la fila existe, tiene un ID asignado y NO estamos en modo borrado, abrimos su vista detallada
        if (fila && fila.dataset.id && !modoEliminarActivo) {
            abrirDetalleColaborador(fila.dataset.id);
        }
    });

    // Escuchamos el CLIC SIMPLE en el cuerpo de la tabla para gestionar la eliminación lógica/física
    tbody.addEventListener('click', async (event) => {
        // Si no tenemos activado el modo eliminar, ignoramos por completo el clic en la fila
        if (!modoEliminarActivo) return;
        
        const fila = event.target.closest('tr');
        if (!fila || !fila.dataset.id) return; 
        
        // Obtenemos el ID único de la entidad y su nombre para el mensaje de confirmación
        const idEntidad = fila.dataset.id;
        const nombreColaborador = fila.cells[0].innerText;

        // Lanzamos un confirm nativo para asegurarnos de que el usuario no ha pulsado por error
        if (confirm(`¿ELIMINAR PERMANENTEMENTE? \nSe borrará "${nombreColaborador}".`)) {
            try {
                // Solicitamos a la API que elimine la entidad de la base de datos
                await apiService.eliminarEntidad(idEntidad);
                alert("Entidad Query eliminada correctamente.");
                
                // Si la API responde bien, borramos directamente la fila del DOM para que el usuario vea el cambio instantáneo
                fila.remove(); 
                
                // Desactivamos el modo eliminar para limpiar la interfaz
                desactivarModoEliminar(aviso, tabla, btnEliminar);
            } catch (error) { 
                alert("Error al eliminar la entidad.");
            }
        }
    });

    // Si existe el botón de activar borrado en la interfaz
    if (btnEliminar) {
        btnEliminar.addEventListener('click', () => {
            // Conmutamos el estado del flag (de true a false o viceversa)
            modoEliminarActivo = !modoEliminarActivo;
            
            // Si acabamos de activar el modo eliminar, cambiamos los estilos visuales a modo "alerta"
            if (modoEliminarActivo) {
                aviso.style.display = 'flex'; // Mostramos la barra superior de aviso
                tabla.classList.add('modo-borrado-activo'); // Añadimos clase CSS (por ejemplo, para poner el cursor en formato 'pointer' o rojo)
                btnEliminar.style.backgroundColor = "#e02424"; // Cambiamos el botón a color rojo
                btnEliminar.style.color = "white";
            } else {
                // Si lo desactivamos, restauramos los estilos normales
                desactivarModoEliminar(aviso, tabla, btnEliminar);
            }
        });
    }

    // Si existe el botón de cancelar dentro de la barra de aviso de borrado
    const btnCancelarBorrado = document.getElementById('btn-cancelar-borrado');
    if (btnCancelarBorrado) {
        btnCancelarBorrado.addEventListener('click', () => {
            // Apagamos el modo eliminar de inmediato
            desactivarModoEliminar(aviso, tabla, btnEliminar);
        });
    }

    // CANAL DE COMUNICACIÓN BROADCAST: Escuchamos eventos enviados desde otros scripts o pestañas
    canalComunicacion.onmessage = (event) => {
        // Si otro formulario (como el de edición lateral) avisa que se han guardado cambios
        if (event.data === 'recargar-tabla') 
        {
            // Refrescamos los datos directamente desde la API
            cargarTablaDinamica(); 
        } 
        // Si nos piden desmarcar o limpiar el flujo del colaborador activo
        else if (event.data === 'resetear-boton-modificar') 
        {
            idColaboradorActivo = null; 
            // Actualizamos el estado del botón modificar del menú superior
            revalidaBotonModificar(); 
        } 
        // Si el panel de filtros nos envía una nueva configuración de búsqueda
        else if (event.data.type === 'aplicar-filtros') 
        {
            // Aplicamos los filtros a la caché en memoria
            aplicarFiltrosDinamicos(event.data.filtros); 
        }
    };

    // Escuchamos la comunicación directa entre iframes jerárquicos
    window.addEventListener('message', (event) => {
        // Reseteo del botón modificar por petición externa
        if (event.data === 'resetear-boton-modificar') 
        {
            idColaboradorActivo = null; 
            revalidaBotonModificar();
        } 
        // Si el usuario cambia de campaña desde el selector global o el menú lateral
        else if (event.data && event.data.type === 'cambiar-campania-local') 
        {
            console.log("Cambio de campaña detectado:", event.data.campania.nombre);
            idCampaniaVisualizada = event.data.campania.id;
            
            // Guardamos de forma persistente la campaña que se está consultando en este momento
            localStorage.setItem("idCampaniaVisualizada", idCampaniaVisualizada); 
            
            // Desactivamos el "Ver todas", pero PRESERVAMOS el resto de filtros activos
            filtrosActivos.todasCampanias = false;
            localStorage.setItem("mostrarTodasCampanias", "false"); 
            
            // Desmarcamos el checkbox en el panel de filtros accediendo de forma segura al iframe del menú lateral
            const iframeMenu = window.parent?.document.querySelector('.menu-lateral-iframe') || document.querySelector('.menu-lateral-iframe');
            if (iframeMenu && iframeMenu.contentWindow) {
                const checkTodas = iframeMenu.contentWindow.document.getElementById('filtro-todas-campanias');
                if (checkTodas) checkTodas.checked = false;
            }

            // Actualizamos el h1 del encabezado con el nombre de la nueva campaña seleccionada y recargamos
            document.querySelector('.encabezado h1').textContent = event.data.campania.nombre;
            cargarTablaDinamica(); 
        }
    });

    // Escuchamos el botón de filtrar para cambiar dinámicamente el contenido del menú lateral al panel de filtros
    document.getElementById('filtrar').onclick = () => {
        if (window.parent) 
        {
            const iframeMenu = window.parent.document.querySelector('.menu-lateral-iframe');
            if (iframeMenu) 
            {
                iframeMenu.src = "../Colaboradores/panelFiltros.html"; 
            }
        }
    };
});

// Función global para cambiar la campaña manualmente (por si se invoca directamente desde consola o desde un evento inline)
window.cambiarCampaniaManual = function(campania) 
{
    idCampaniaVisualizada = campania.id;
    localStorage.setItem("idCampaniaVisualizada", idCampaniaVisualizada); 
    
    // Al seleccionar una campaña concreta, forzamos que se apague el modo de visualizar todas a la vez
    filtrosActivos.todasCampanias = false;
    localStorage.setItem("mostrarTodasCampanias", "false"); 
    
    document.querySelector('.encabezado h1').textContent = campania.nombre;
    cargarTablaDinamica(); 
};

// Función asíncrona principal encargada de devorar los datos de la API y sincronizar memorias locales
async function cargarTablaDinamica() {
    // Encendemos el spinner/loader visual en la pantalla
    toggleLoader(true); 
    try 
    {
        // Lanzamos de forma paralela las peticiones de entidades y campañas para optimizar tiempos de respuesta
        const [todas, campanias] = await Promise.all([
            apiService.obtenerEntidades(),
            apiService.obtenerCampanias()
        ]);
        
        // Guardamos los resultados frescos en nuestras variables globales de respaldo
        colaboradoresOriginales = todas;
        campaniasCache = campanias; 
        
        // Hacemos un backup rápido en sessionStorage por si otras vistas necesitan inspeccionar la lista completa
        sessionStorage.setItem("colaboradoresCache", JSON.stringify(todas));

        // Determinamos qué campaña debemos renderizar leyendo primero si hay alguna preferencia guardada en el navegador
        const guardada = localStorage.getItem("idCampaniaVisualizada");
        if (guardada) 
        {
            idCampaniaVisualizada = parseInt(guardada);
        } 
        else if (campanias.length > 0) 
        {
            // Si no hay ninguna guardada, buscamos la campaña que venga marcada como activa de origen o agarramos la primera
            const campaniaActiva = campanias.find(c => c.activa === true) || campanias[0];
            idCampaniaVisualizada = campaniaActiva.id;
            localStorage.setItem("idCampaniaVisualizada", idCampaniaVisualizada);
        }

        // Sincronizamos el estado en memoria con lo almacenado en LocalStorage sobre si se deben ver todas las campañas
        filtrosActivos.todasCampanias = localStorage.getItem("mostrarTodasCampanias") === "true";

        // Si no estamos en modo "Ver todas las campañas", actualizamos el título de la página con el nombre de la campaña activa
        const def = campanias.find(c => c.id === idCampaniaVisualizada);
        if (def && localStorage.getItem("mostrarTodasCampanias") !== "true") 
        {
            document.querySelector('.encabezado h1').textContent = def.nombre;
        }

        // Reaplicamos el filtro activo directamente (Mantiene las búsquedas vivas tras cambios o refrescos)
        aplicarFiltrosDinamicos(filtrosActivos);

    } 
    catch (error) 
    { 
        console.error("Fallo al cargar la tabla:", error);
    } 
    finally 
    {
        // Apagamos definitivamente el spinner de carga
        toggleLoader(false); 
    }
}

// Procesa, filtra la lista en memoria según los criterios activos y calcula el contador visual del badge
function aplicarFiltrosDinamicos(f) 
{
    // Sobreescribimos la memoria de filtros del módulo con los nuevos criterios
    filtrosActivos = f; 
    
    // Calculamos cuántos filtros del panel están modificados para actualizar el numerito (badge)
    let contadorFiltros = 0;
    if (f.tienda) contadorFiltros++;
    if (f.localidad) contadorFiltros++;
    if (f.todasCampanias) contadorFiltros++;
    if (f.soloCapital) contadorFiltros++;
    if (f.soloActiva) contadorFiltros++;

    // Buscamos el contenedor del botón de filtrado en la barra superior
    const contenedorFiltro = document.querySelector('.boton-filtro');
    if (contenedorFiltro) 
    {
        // Si ya existía un numerito previo pintado, lo eliminamos para evitar duplicados
        const badgeExistente = contenedorFiltro.querySelector('.badge-filtros');
        if (badgeExistente) badgeExistente.remove();

        // Si hay al menos un filtro activo, fabricamos un span dinámico y lo inyectamos en el botón
        if (contadorFiltros > 0) 
        {
            const badge = document.createElement('span');
            badge.className = 'badge-filtros';
            badge.textContent = contadorFiltros;
            contenedorFiltro.appendChild(badge);
        }
    }

    // Empezamos el proceso de cribado partiendo de la lista original completa
    let filtrados = colaboradoresOriginales;
    
    // Aplicamos filtros secuenciales sobre atributos directos de la entidad
    if (f.localidad) filtrados = filtrados.filter(c => c.localidadNombre === f.localidad);
    if (f.soloCapital) filtrados = filtrados.filter(c => c.esCapital === true); 
    if (f.soloActiva) filtrados = filtrados.filter(c => c.estadoActivo === true);

    // Sincronizamos la persistencia del estado global del filtro por campaña
    localStorage.setItem("mostrarTodasCampanias", f.todasCampanias);

    // Normalizamos el término de búsqueda de la tienda a mayúsculas y quitamos espacios en blanco
    const terminoTienda = f.tienda ? f.tienda.trim().toUpperCase() : "";

    // CASO A: El usuario quiere ver la información distribuida y agrupada por todas las campañas de la app
    if (f.todasCampanias) 
    {
        document.querySelector('.encabezado h1').textContent = "Todas las campañas";
        
        // Si hay un término de búsqueda para la tienda, aplanamos las tiendas de todas las campañas del colaborador para ver si coincide
        if (terminoTienda) 
        {
            filtrados = filtrados.filter(c => {
                const todasSusTiendas = c.tiendasPorCampania ? Object.values(c.tiendasPorCampania).flat() : c.nombresTiendas || [];
                return todasSusTiendas.some(t => t.toUpperCase().includes(terminoTienda));
            });
        }
        // Pasamos el testigo a la función de renderizado complejo por secciones agrupadas
        renderizarTablaAgrupadaPorCampania(filtrados, terminoTienda); 
    } 
    // CASO B: Renderizado normal filtrado por la campaña que tenemos seleccionada visualmente
    else 
    {
        const def = campaniasCache.find(c => c.id == idCampaniaVisualizada);
        if (def) document.querySelector('.encabezado h1').textContent = def.nombre;
        
        // Si hay término de tienda, filtramos garantizando que solo busque en el nodo de la campaña visualizada actualmente
        if (terminoTienda) 
        {
            filtrados = filtrados.filter(c => {
                const tiendasDeEstaCampania = c.tiendasPorCampania ? (c.tiendasPorCampania[idCampaniaVisualizada] || []) : c.nombresTiendas || [];
                return tiendasDeEstaCampania.some(t => t.toUpperCase().includes(terminoTienda));
            });
        }
        
        // Nos aseguramos de que el colaborador realmente participe de forma explícita en la campaña visualizada antes de pintar
        const entidadesAMostrar = filtrados.filter(c => c.idsCampanias?.includes(idCampaniaVisualizada));
        renderizarFilasNormales(entidadesAMostrar);
    }

    // Validamos si el botón de modificar del menú superior debe habilitarse o quedarse bloqueado
    revalidaBotonModificar();
}

// Vacía la tabla y pinta los colaboradores en formato de lista plana convencional
function renderizarFilasNormales(datos) 
{
    colaboradoresCache = datos; 
    window.colaboradoresCache = datos; // Hace visible la caché actual para que exportarCSV.js pueda descargar exactamente lo que se ve en pantalla
    
    const tbody = document.querySelector('#tabla-body');
    tbody.innerHTML = ''; // Vaciamos por completo las filas antiguas
    
    // Inyectamos las nuevas filas asociándolas al contexto de la campaña actual
    inyectarFilasEnContenedor(datos, tbody, idCampaniaVisualizada);
}

// Genera una estructura de tabla organizada inyectando filas de cabeceras oscuras separadoras por cada campaña maestra
function renderizarTablaAgrupadaPorCampania(datos, textoTiendaFiltro = null) 
{
    colaboradoresCache = datos;
    window.colaboradoresCache = datos; // Hace visible la caché actual para que exportarCSV.js pueda descargar exactamente lo que se ve en pantalla
    
    const tbody = document.querySelector('#tabla-body');
    tbody.innerHTML = '';

    // Iteramos el catálogo maestro de campañas para ir abriendo bloques separadores individuales en la tabla
    campaniasCache.forEach(campania => {
        // Filtramos qué colaboradores pertenecen a la iteración de esta campaña concreta
        let colaboradoresDeEstaCampania = datos.filter(c => c.idsCampanias?.includes(campania.id));

        // Si el usuario introdujo una tienda en el buscador, volvemos a cribar para que solo entren los que tengan esa tienda en esta campaña específica
        if (textoTiendaFiltro) 
        {
            colaboradoresDeEstaCampania = colaboradoresDeEstaCampania.filter(c => {
                const tiendasCamp = c.tiendasPorCampania ? (c.tiendasPorCampania[campania.id] || []) : c.nombresTiendas || [];
                return tiendasCamp.some(t => t.toUpperCase().includes(textoTiendaFiltro));
            });
        }

        // Si tras los filtros queda algún colaborador vivo en esta campaña, pintamos el separador de sección y sus registros
        if (colaboradoresDeEstaCampania.length > 0) 
        {
            const filaCabecera = document.createElement('tr');
            filaCabecera.innerHTML = `<td colspan="6" class="fila-seccion-campania"> CAMPAÑA: ${campania.nombre.toUpperCase()}</td>`;
            tbody.appendChild(filaCabecera);

            // Inyectamos el subconjunto de colaboradores debajo de la cabecera divisoria recién creada
            inyectarFilasEnContenedor(colaboradoresDeEstaCampania, tbody, campania.id);
        }
    });
}

// Fábrica pura de manipulación de DOM: Recorre la lista, construye los strings HTML e inyecta las filas tr reales
function inyectarFilasEnContenedor(lista, contenedor, idCampaniaContexto) 
{
    lista.forEach(colab => {
        const fila = document.createElement('tr');
        fila.dataset.id = colab.id; // Vinculamos el ID de la base de datos en el atributo data-id para recuperarlo en clics/doble clics

        // Buscamos el contacto que sea el encargado o gestor principal de la entidad
        const principal = colab.responsables?.find(r => r.esPrincipal);
        const contactoHtml = principal ? `${principal.nombre} <br><small>${principal.email}</small>` : "Sin contacto";
        
        // Resolvemos el listado de nombres de tiendas asociadas evaluando el mapa de campañas o recurriendo al array genérico por defecto
        const listaT = colab.tiendasPorCampania ? (colab.tiendasPorCampania[idCampaniaContexto] || []) : [...new Set(colab.nombresTiendas || [])];
        
        // Maquetamos el mini-componente colapsable de tiendas (muestra la primera y esconde el resto en un contenedor oculto)
        const tiendasHtml = `
            <div class="tiendas-resumen">${listaT[0] || '---'} ${listaT.length > 1 ? `<b>(+${listaT.length - 1})</b>` : ''}</div>
            <div class="tiendas-lista-completa" style="display: none;">
                ${listaT.map(t => `<div style="margin-bottom: 10px;">- ${t}</div>`).join('')}
            </div>
        `;

        // Estructuramos el esqueleto final de celdas (td) de la fila
        fila.innerHTML = `
            <td>${colab.nombre}</td>
            <td>${colab.domicilioCompleto}</td>
            <td>${colab.localidadNombre}</td>
            <td>${contactoHtml}</td>
            <td>${tiendasHtml}</td>
            <td class="desplegar" onclick="desplegarTiendas(this)">&nbsp;</td>
        `;
        // Agregamos la fila terminada al contenedor tbody correspondiente
        contenedor.appendChild(fila);
    });
}

// Guarda el colaborador seleccionado en la sesión del navegador y redirige el iframe lateral para mostrar sus fichas
function abrirDetalleColaborador(id) 
{
    // Buscamos el colaborador que coincide con el ID clicado dentro de nuestra caché actual en pantalla
    const colaborador = colaboradoresCache.find(c => c.id == id);
    if (colaborador) {
        // Guardamos el objeto entero serializado en JSON dentro del sessionStorage para que lo lea 'colaboradorSeleccionado.js'
        sessionStorage.setItem("colaboradorSeleccionado", JSON.stringify(colaborador));
        idColaboradorActivo = id; // Fijamos este ID como el elemento seleccionado del sistema
        
        // Refrescamos el estado de los controles de la aplicación
        revalidaBotonModificar();

        // Si estamos corriendo dentro de una arquitectura de frames, cambiamos la URL del menú lateral para cargar la ficha del colaborador
        if (window.parent && window.parent.document) {
            const iframeMenu = window.parent.document.querySelector(".menu-lateral-iframe");
            if (iframeMenu) iframeMenu.src = "../Colaboradores/colaboradorSeleccionado.html";
        }
    }
}

// Controla el estado del botón Modificar de la botonera principal superior en base a si hay o no un colaborador seleccionado
function revalidaBotonModificar() 
{
    const btnModificar = document.getElementById('btn-modificar-colaborador');
    const iframeMenu = window.parent?.document.querySelector('.menu-lateral-iframe') || document.querySelector('.menu-lateral-iframe');

    if (btnModificar) 
    {
        // Si tenemos un colaborador activo, convertimos el botón a un estado "vivo" y clickable
        if (idColaboradorActivo !== null) {
            btnModificar.classList.replace('desactivado', 'activado');
            btnModificar.title = "Modificar los datos del colaborador seleccionado";
            
            // Asignamos el manejador del clic encargado de disparar el postMessage hacia el formulario interno de edición
            btnModificar.onclick = () => {
                if (iframeMenu && iframeMenu.contentWindow) {
                    // Emitimos la señal mágica para que el formulario alterne entre modo lectura y modo edición
                    iframeMenu.contentWindow.postMessage('toggle-edicion-lateral', '*');
                    
                    // Pequeño truco estético: metemos una sombra azul de destello para guiar el ojo del usuario hacia el panel que acaba de activarse
                    iframeMenu.style.boxShadow = "0 0 15px rgba(37, 99, 235, 0.5)";
                    setTimeout(() => iframeMenu.style.boxShadow = "none", 1000);
                }
            };
        } 
        else 
        {
            // Si no hay selección, llamamos a la rutina de bloqueo seguro
            resetearBotonModificar();
        }
    }
}

// Devuelve el botón de modificar del menú superior a su estado inactivo original bloqueando sus clics
function resetearBotonModificar() 
{
    const btnModificar = document.getElementById('btn-modificar-colaborador');
    if (btnModificar) 
    {
        btnModificar.classList.replace('activado', 'desactivado');
        btnModificar.title = "Debes primero seleccionar un colaborador";
        btnModificar.onclick = null; // Eliminamos cualquier función asignada previamente para evitar fugas de clics
    }
}

// Limpia los estilos de alerta del borrado masivo/individual devolviendo la tabla a su comportamiento estándar
function desactivarModoEliminar(aviso, tabla, btn) 
{
    modoEliminarActivo = false;
    if (aviso) aviso.style.display = 'none'; // Escondemos el banner de advertencia superior
    if (tabla) tabla.classList.remove('modo-borrado-activo'); // Quitamos las clases de peligro CSS
    if (btn) {
        // Reseteamos las propiedades inline de color para que vuelvan a mandar las hojas de estilo CSS limpias
        btn.style.backgroundColor = ""; 
        btn.style.color = "";
    }
}

// Efecto acordeón/desplegable para la columna de tiendas de la tabla
window.desplegarTiendas = function(celdaBoton) 
{
    // Buscamos la celda td anterior, que es la que guarda los divs de resumen y lista completa
    const celdaTiendas = celdaBoton.previousElementSibling;
    if (!celdaTiendas) return;
    
    const resumen = celdaTiendas.querySelector('.tiendas-resumen');
    const listaCompleta = celdaTiendas.querySelector('.tiendas-lista-completa');
    
    if (resumen && listaCompleta) {
        // Evaluamos si el listado extendido está oculto actualmente
        const estaOculta = listaCompleta.style.display === 'none';
        
        // Alternamos los displays invirtiendo sus estados de visibilidad
        listaCompleta.style.display = estaOculta ? 'block' : 'none';
        resumen.style.display = estaOculta ? 'none' : 'block';
        
        // Añadimos o quitamos la clase de rotación para que la flechita del botón gire grácilmente 90° o 180° grados
        if (estaOculta) 
        {
            celdaBoton.classList.add('rotado');
        } else 
        {
            celdaBoton.classList.remove('rotado');
        }
    }
};
