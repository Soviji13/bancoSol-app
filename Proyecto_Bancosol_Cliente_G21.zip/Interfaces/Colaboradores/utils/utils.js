// FUNCIONES "GLOBALES" (por ahora loader)

// Instanciamos el canal de comunicación una sola vez para toda la app
// Usamos BroadcastChannel para poder enviar y recibir mensajes o eventos entre diferentes pestañas e iframes del mismo origen de forma nativa
export const canalComunicacion = new BroadcastChannel('bancosol_channel');

// Función genérica para mostrar/ocultar el loader
// mostrar -> Booleano (true para activar el spinner en pantalla, false para esconderlo)
export function toggleLoader(mostrar) { 

    // Obtenemos el elemento de loading buscando su identificador único en el DOM de la página
    let loader = document.getElementById('loading-overlay'); 

    // Si no existía y se quiere msotrar (primera pasada)
    if (mostrar && !loader) 
    { 
        // Creamos el loader desde cero fabricando dinámicamente un nodo div en el aire
        loader = document.createElement('div'); 
        loader.id = 'loading-overlay'; 
        loader.className = 'loading-overlay'; 
        
        // Inyectamos la estructura HTML interior con las clases del CSS para pintar el spinner y el texto de espera
        loader.innerHTML = ` 
        <div class="spinner"></div> 
        <div class="loading-text">Cargando datos... Por favor, espere</div> 
        `; 

        // Lo añadimos al documento enganchándolo directamente al final del nodo body para que se superponga a todo
        document.body.appendChild(loader); 
    } 

    // Si existía el elemento loader en la página (ya sea porque ya estaba creado de antes o porque lo acabamos de fabricar arriba)
    if (loader) 
    { 
        // Si se desea mostrar, cambiamos su propiedad inline a 'flex' (esencial para centrar el spinner); si no, lo ocultamos con 'none'
        loader.style.display = mostrar ? 'flex' : 'none'; 
    } 
}