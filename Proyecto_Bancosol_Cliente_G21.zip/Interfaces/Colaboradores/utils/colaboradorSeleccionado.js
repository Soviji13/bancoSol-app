/*************************************************************************************
 * LÓGICA DE VER INFORMACIÓN DE UN COLABORADOR COMPLETA Y DE PODER MODIFICARLO
 *************************************************************************************/

// Importamos apiService y canalComunicación para poder acceder bien a los datos
import { apiService } from './apiService.js';
import { canalComunicacion } from './utils.js';

// Cuando se haya cargado todo el DOM estático y todos los scripts:
document.addEventListener('DOMContentLoaded', async () => {

    // Cargamos todas las opciones (CPs, Localidades, Tiendas, Campañas) - Sobretodo por si se decide modificar en un futuro una entidad colaboradora. Mientras se obtienen, se pone un loader.
    await cargarListasDesplegables();

    // Cargar los datos específicos del colaborador seleccionado
    cargarDatosFormulario();

    // Si la ventana recibe el evento de modificar la entidad colaboradora
    window.addEventListener('message', (event) => {
        if (event.data === 'toggle-edicion-lateral') {
            toggleModoEdicion();
        }
    });

    // MENÚ LATERAL

    // Si se encuentra el botón de cerrar panel, se activa la función para poder cerrar el panel lateral
    document.getElementById('btn-cerrar-panel')?.addEventListener('click', cerrarPanelLateral);

    // Si se encuentra el botón de agregar contacto, se activa la función de poder agregar un nuevo contacto (responsable de entidad)
    document.getElementById('btn-add-contacto')?.addEventListener('click', () => renderizarBloqueContacto({}, null, true));

    // Si se encuentra el formulario de edición (modo editar activo), se activa la función de poder guardar los cambios realizados
    document.getElementById('form-edicion-lateral')?.addEventListener('submit', guardarCambiosReales);
});

// Función para activar/desactivar el modo edición
function toggleModoEdicion() {

    // Obtenemos del documento el formulario de edición
    const form = document.getElementById('form-edicion-lateral');
    
    // Si nos encontrábamos en modo lectura, pasamos a modo edición
    if (form.classList.contains('modo-lectura')) {
        form.classList.replace('modo-lectura', 'modo-edicion');
        
        // Ponemos todos los inputs, textArea y select activos
        form.querySelectorAll('input, textarea, select').forEach(el => {
            el.removeAttribute('readonly');
            el.removeAttribute('disabled');
        });

        // Mostramos los botones para poder actualizar la información, añadir un nuevo responsable de entidad, hacemos focus automático a edit-calle
        document.getElementById('btn-guardar-container').style.display = 'block';
        document.getElementById('btn-add-contacto-container').style.display = 'block';
        document.getElementById('edit-calle').focus();
    } 
    // Si nos encontrábamos en modo edición, pasamos a modo lectura
    else 
    {
        // Pasamos a modo lectura y cerramos el modo edición
        form.classList.replace('modo-edicion', 'modo-lectura');
        
        // Volvemos a reestablecer el modo de lectura únicamente en los inputs del form y en los textarea y selects
        form.querySelectorAll('input, textarea, select').forEach(el => {
            if (el.tagName === 'SELECT' || el.type === 'checkbox' || el.type === 'radio') {
                el.setAttribute('disabled', 'true');
            } else {
                el.setAttribute('readonly', 'true');
            }
        });

        // Ocultamos el botón de guardar y el de añadir nuevo responsable
        document.getElementById('btn-guardar-container').style.display = 'none';
        document.getElementById('btn-add-contacto-container').style.display = 'none';
        
        // Cargamos los datos del formulario
        cargarDatosFormulario();
    }
}

// Cargamos listas desplegables (datos maestros) para la posible modificación y también visualización de la información
async function cargarListasDesplegables() {

    // Creamos un div para el loader lateral (se muestra mientras se van obteniendo los datos)
    const loaderLateral = document.createElement('div');
    loaderLateral.className = 'loading-overlay';
    loaderLateral.style.position = 'absolute'; 
    loaderLateral.innerHTML = '<div class="spinner"></div>';
    document.querySelector('.panel-colaborador').appendChild(loaderLateral);

    // Intentamos obtener los datos 
    try {

        const [resCps, resLocs, resTiendas, resCampanias, resZonas, resDists] = await Promise.all([
            apiService.obtenerCodigosPostales(),
            apiService.obtenerLocalidades(),
            apiService.obtenerTiendas(),
            apiService.obtenerCampanias(),
            apiService.obtenerZonasGeograficas(),
            apiService.obtenerDistritos()
        ]);

        // Añadimos a los selects las opciones posibles (cp, localidad, zona geográfica, distrito)
        document.getElementById('edit-cp').innerHTML = '<option value="">CP...</option>' + resCps.map(cp => `<option value="${cp.codigo}">${cp.codigo}</option>`).join('');
        document.getElementById('edit-localidad').innerHTML = '<option value="">Localidad...</option>' + resLocs.map(l => `<option value="${l.nombre}">${l.nombre}</option>`).join('');
        document.getElementById('edit-zona').innerHTML = '<option value="">Zona Geográfica...</option>' + resZonas.map(z => `<option value="${z.nombre}">${z.nombre}</option>`).join('');
        document.getElementById('edit-distrito').innerHTML = '<option value="">Distrito...</option>' + resDists.map(d => `<option value="${d.nombre}">${d.nombre}</option>`).join('');

        // Añadimos las tiendas en forma de checkbox (desabilitadas por ahora), accediendo primero al panel de tiendas
        const contTiendas = document.getElementById('check-tiendas-panel');
        contTiendas.innerHTML = resTiendas.map(t => 
            `<label><input type="checkbox" value="${t.id}" class="check-tienda-panel" disabled> ${t.nombre}</label>`
        ).join('');

        // Obtenemos el panel de las campañas
        const contCampanias = document.getElementById('check-campanias-panel');
    
        // Recorremos las campañas existentes y vamos añadiendo cada una al panel:
        // En <label> va el nombre de la campaña con su checkbox (tick si participa en ella)
        // En <div class="campania-panel-item-tiendas"> Van todas las tiendas existentes con su checkbox (por cada campaña)
        contCampanias.innerHTML = resCampanias.map(c => `
            <div class="campania-panel-item">

                <label>
                    <input type="checkbox" value="${c.id}" class="check-campania-master panel-cb" disabled onchange="toggleTiendasPanel(this, ${c.id})" style="flex-shrink: 0; width: 16px; height: 16px; margin: 0;">
                    <span style="line-height: 1.4; flex: 1; white-space: normal; text-align: left; word-break: break-word;">${c.nombre}</span>
                </label>
                
                <div id="tiendas-campania-panel-${c.id}" class="campania-panel-item-tiendas" style="">
                    ${resTiendas.filter(t => c.idsTiendas && c.idsTiendas.includes(t.id)).map(t => `
                        <label style="display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px; font-size: 0.9em; cursor: pointer; color: #334155; width: 100%; box-sizing: border-box;">
                            <input type="checkbox" value="${t.id}" class="check-tienda-sub panel-cb" disabled style="margin-top: 3px; flex-shrink: 0; width: 14px; height: 14px; margin-left: 0;">
                            <span style="flex: 1; white-space: normal; text-align: left; line-height: 1.3; word-break: break-word;">${t.nombre}</span>
                        </label>
                    `).join('')}
                </div>
            </div>
        `).join('');

        // Función que se activa si una la entidad colaboradora participa en la campaña 
        // Influye sobre el listado de tiendas de cada campaña
        // cb -> Objeto
        // id -> id de la campaña
        window.toggleTiendasPanel = function(cb, id) 
        {
            // Obtenemos las tiendas de esas campañas
            const div = document.getElementById(`tiendas-campania-panel-${id}`);

            // Si esa campaña está "checked", se muestran las tiendas abajo, si no, no se muestran
            if (div) div.style.display = cb.checked ? 'block' : 'none';
        };

    } catch (e) 
    {
        console.error("Fallo al cargar datos maestros del panel", e);
    } 
    // Cuando se hayan capturado los datos, el loader se va
    finally 
    {
        loaderLateral.remove();
    }
}

// Cargar los datos de la entidad colaboradora mostrada
function cargarDatosFormulario() {

    // Obtenemos los datos de la entidad colaboradora seleccionada
    const colab = JSON.parse(sessionStorage.getItem("colaboradorSeleccionado"));

    // Si no se han podido obtener, paramos la función
    if (!colab) return;

    // ACCESO A DOMICILIO 
    let calle = colab.calle || "";
    let numero = colab.numero || "";

    // Si no hay calle, pero sí domicilio completo, lo dividimos desde aquí
    if (!calle && colab.domicilioCompleto) 
    {
        const partes = colab.domicilioCompleto.split(',');
        calle = partes[0] ? partes[0].trim() : "";
        numero = partes[1] ? parseInt(partes[1].trim()) : "";
    }

    // Introducimos los atributos del colaborador seleccionado en los elementos del DOM
    document.getElementById('titulo-colaborador').value = colab.nombre || "";
    document.getElementById('colaborador-id').value = colab.id;
    document.getElementById('detalle-id-display').textContent = `A${String(colab.id).padStart(5, '0')}`;
    document.getElementById('check-campania').checked = colab.estadoActivo;
    document.getElementById('edit-observaciones').value = colab.observaciones || "";
    document.getElementById('edit-calle').value = calle;
    document.getElementById('edit-numero').value = numero;
    document.getElementById('edit-localidad').value = colab.localidadNombre || "";
    document.getElementById('edit-cp').value = colab.codigoPostal || "";

    // PANEL DE TIENDAS GLOBALES 

    // Obtenemos todas las tiendas asociadas a la entidad colaboradora en la campaña
    let misTiendasNombres = [];

    // Si se han podido acceder a las tiendas por campaña del colaborador
    if (colab.tiendasPorCampania) 
    {
        // Las añadimos a un nuevo array aplanado
        /**
         * Ejemplo: En vez de {1:{tienda1, tienda2}, 2:{tienda2}} -> {tienda1, tienda2}
         * ELIMINA LOS REPETIDOS
         */
        misTiendasNombres = [...new Set(Object.values(colab.tiendasPorCampania).flat())];
    }
    // Si no se pueden obtener, obtendremos o todas sus tiendas (sin importar la campaña) o un array vacío si tampoco se pudieron obtener todas sus tiendas 
    else 
    {
        misTiendasNombres = colab.nombresTiendas || [];
    }

    // Ponemos check las tiendas que contiene la entidad colaboradora (para el panel genérico de tiendas)
    document.querySelectorAll('.check-tienda-panel').forEach(cb => {
        const nombreTiendaEnPanel = cb.parentElement.textContent.trim();
        cb.checked = misTiendasNombres.includes(nombreTiendaEnPanel);
    });

    // PANEL DE TIENDAS POR CAMPAÑA

    // Obtenemos las campañas en las que colabora y las tiendas en las que colabora de cada campaña específica
    const misIdsCampanias = colab.idsCampanias || [];
    const misIdsTiendasMap = colab.idsTiendasPorCampania || {}; 

    // Recorremos cada campaña (cada una es un check en el desplegable), independientemente de si la entidad colaboradora participa en ella
    document.querySelectorAll('.check-campania-master').forEach(cb => {

        // Obtenemos el valor del checkbox, que es el id de la campaña correspondiente
        const campId = parseInt(cb.value);

        // Si esa campaña es una en la que la entidad colaboradora participa
        if (misIdsCampanias.includes(campId)) 
        {
            // Ponemos el checkbox "checked"
            cb.checked = true;

            // Accedemos al subpanel donde se ven las tiendas en las que participa la entidad colaboradora en esa campaña
            // Se creó ya en cargarDatosFormulario()
            const subPanel = document.getElementById(`tiendas-campania-panel-${campId}`);

            // Si el subpanel existe
            if (subPanel) 
            {
                // Lo mostramos (por defecto estaba display:none)
                subPanel.style.display = 'block';

                // Obtenemos las tiendas asignadas a esa campaña a esa entidad colaboradora
                const tiendasAsignadas = misIdsTiendasMap[campId] || [];

                // Accedemos al checkbox de cada tienda (independientemente de si el colaborador participa en ella en esa campaña)
                subPanel.querySelectorAll('.check-tienda-sub').forEach(tcb => {
                    // Si la tienda es una en la que participa, tbc (el input en el DOM que representa a la tienda) se pondrá "checked"
                    tcb.checked = tiendasAsignadas.includes(parseInt(tcb.value));
                });
            }
        }
    });

    // PANEL DE RESPONSABLES DE ENTIDAD

    // Obtenemos la tabla de contactos
    const tbody = document.getElementById('tabla-contactos-dinamica');

    // Limpiamos la tabla para evitar sobreescrituras
    tbody.innerHTML = ''; 

    // Si el colaborador tiene responsables de entidad
    if (colab.responsables && colab.responsables.length > 0) 
    {
        // Por cada responsable, renderizamos su bloque
        colab.responsables.forEach((resp, index) => renderizarBloqueContacto(resp, index, false));
    } 
    // Si no tiene responsables de entidad
    else 
    {
        // Renderizamos el bloque de contacto vacío
        renderizarBloqueContacto({}, 0, false);
    }

    // RESTO DE ATRIBUTOS

    // Zona geográfica
    document.getElementById('edit-zona').value = colab.zonaNombre || "";
    const checkCapital = document.getElementById('check-es-capital-panel');

    // Es capital
    checkCapital.checked = colab.esCapital || false;
    
    // Distrito
    const divDistrito = document.getElementById('campo-distrito-panel');

    // Si el colaborador se encuentra en capital
    if (colab.esCapital) 
    {
        // Se activa la visibilidad de distrito junto a su posible edición
        divDistrito.style.display = 'flex';
        document.getElementById('edit-distrito').value = colab.distritoNombre || "";
    } 
    // Si no se encuentra en capital, no mostramos nada
    else 
    {
        divDistrito.style.display = 'none';
    }

    // Si capital cambia (checked -> no checked y viceversa)
    checkCapital.onchange = function() {
        // Cambiamos la visibilidad de distrito (en función de si se ha marcado o no)
        divDistrito.style.display = this.checked ? 'flex' : 'none';
    };
}

// Para renderizar cada responsable de entidad (por defecto, no será nuevo)
function renderizarBloqueContacto(resp, index = null, esNuevo = false) 
{
    // Obtenemos la tabla de contactos (responsables de entidad)
    const tbody = document.getElementById('tabla-contactos-dinamica');

    // Obtenemos el índice del responsable de entidad (si no se puede obtener, obtenemos el último)
    const currIndex = index !== null ? index : (tbody.querySelectorAll('.contacto-header').length);

    // Obtenemos el modo edición (por si se activa)
    const form = document.getElementById('form-edicion-lateral');

    // Flag para saber si nos encontramos en modo edición
    const estaEnEdicion = form.classList.contains('modo-edicion');
    
    // Flags en función de si nos encontramos en modo edición
    const disabledAtr = estaEnEdicion ? '' : 'disabled';
    const readonlyAtr = estaEnEdicion ? '' : 'readonly';

    // Si es nuevo, añadimos más columnas (5), si no, mostramos 3 columnas
    const rowspan = esNuevo ? 5 : 3;

    // Bloque que se mostrará por cada responsable de entidad
    let html = `
        <tr class="contacto-header">
            <td rowspan="${rowspan}" style="width: 90px; text-align: center; vertical-align: top; background-color: #f8fafc;">
                <strong style="color: #1e3a8a;">Contacto ${currIndex + 1}</strong><br>
                <label style="cursor: pointer; display: inline-block; margin-top: 8px;">
                    <span style="color: #dc2626; font-size: 12px; display: block; margin-bottom: 2px;">Principal</span>
                    <input type="radio" name="radio-principal" class="check-inline r-principal" ${resp.esPrincipal ? 'checked' : ''} ${disabledAtr}>
                </label>
                <button type="button" class="btn-eliminar-contacto" onclick="eliminarContacto(this)" style="${estaEnEdicion ? 'display:block;' : 'display:none;'} color:red; margin-top:10px; cursor:pointer; width: 100%; border: none; background: none; font-size: 12px;">🗑️ Borrar</button>
            </td>
            <td><span class="etiqueta-tabla">Nombre</span> <input type="text" class="input-linea r-nombre" value="${resp.nombre || ''}" ${readonlyAtr}></td>
        </tr>
        <tr><td><span class="etiqueta-tabla">Email</span> <input type="email" class="input-linea r-email" value="${resp.email || ''}" ${readonlyAtr}></td></tr>
        <tr><td><span class="etiqueta-tabla">Telef.</span> <input type="tel" class="input-linea r-telefono" value="${resp.telefono || ''}" ${readonlyAtr}></td></tr>
    `;

    // Si el contacto es completamente nuevo, le inyectamos los inputs extra para las credenciales (obligatorios para el login)
    if (esNuevo) {
        html += `
            <tr><td><span class="etiqueta-tabla">Usuario</span> <input type="text" class="input-linea r-user" placeholder="Login (email)" required></td></tr>
            <tr><td><span class="etiqueta-tabla">Contraseña</span> <input type="password" class="input-linea r-pass" placeholder="Contraseña" required></td></tr>
        `;
    }
    
    // Insertamos toda la estructura HTML generada al final del cuerpo de nuestra tabla dinámica
    tbody.insertAdjacentHTML('beforeend', html);
}

// Función global asignada a window para borrar el bloque de un contacto completo desde su respectivo botón "Borrar"
window.eliminarContacto = function(btn) {
    // Localizamos la fila principal que contiene el botón clicado (la primera del bloque de ese contacto, que lleva el rowspan)
    const trPrincipal = btn.closest('tr');
    
    // Obtenemos cuántas filas ocupa este contacto leyendo el valor de rowspan de la primera celda
    const filasABorrar = parseInt(trPrincipal.querySelector('td').rowSpan);
    
    // Inicializamos el puntero en la fila principal del contacto
    let filaActual = trPrincipal;
    
    // Iteramos en cadena tantas veces como filas tenga el bloque completo para borrarlas una a una del DOM
    for (let i = 0; i < filasABorrar; i++) {
        // Guardamos una referencia a la fila inmediatamente siguiente antes de cargarnos la actual
        let siguienteFila = filaActual.nextElementSibling;
        
        // Eliminamos físicamente del DOM la fila actual en la que estamos parados
        filaActual.remove();
        
        // Saltamos a la siguiente fila para poder procesarla en la siguiente vuelta del bucle
        filaActual = siguienteFila;
    }
}

// Función asíncrona que procesa la validación del submit, recopila todos los inputs editados y lanza la petición de actualización a la API
async function guardarCambiosReales(e) {
    // Frenamos el comportamiento por defecto del evento submit para impedir que recargue la página entera
    e.preventDefault();
    
    // Recuperamos el ID de la entidad desde el campo oculto
    const idEntidad = document.getElementById('colaborador-id').value;
    
    // Inicializamos el array donde estructuraremos cada uno de los responsables recopilados de la tabla
    const responsables = [];
    
    // Recorremos cada cabecera de contacto pintada en nuestra tabla dinámica para procesar sus respectivos datos
    document.querySelectorAll('.contacto-header').forEach(filaPrincipal => {
        // Navegamos por los nodos hermanos (filas consecutivas) para obtener los valores del email y del teléfono
        const email = filaPrincipal.nextElementSibling.querySelector('.r-email').value.trim();
        const telefono = filaPrincipal.nextElementSibling.nextElementSibling.querySelector('.r-telefono').value.trim();
        
        // Construimos la estructura base del contacto, pasando el nombre siempre a mayúsculas
        const respObj = {
            nombre: filaPrincipal.querySelector('.r-nombre').value.trim().toUpperCase(),
            email: email,
            telefono: telefono,
            esPrincipal: filaPrincipal.querySelector('.r-principal').checked
        };

        // Identificamos si existe una tercera fila consecutiva con el campo de usuario (comprobando si es un contacto nuevo)
        const rowUser = filaPrincipal.nextElementSibling.nextElementSibling.nextElementSibling;
        if (rowUser && rowUser.querySelector('.r-user')) {
            // Si existe la fila de credenciales, añadimos el username y el password al objeto final
            respObj.username = rowUser.querySelector('.r-user').value.trim();
            respObj.password = rowUser.nextElementSibling.querySelector('.r-pass').value;
        }
        
        // Añadimos el objeto con los datos procesados del contacto al array general de responsables
        responsables.push(respObj);
    });

    // Inicializamos las estructuras temporales para consolidar las campañas y tiendas seleccionadas
    const idsCampaniasActualizadas = [];
    const tiendasPorCampaniaActualizadas = {};

    // Buscamos todas las campañas maestras que el usuario haya dejado seleccionadas
    document.querySelectorAll('.check-campania-master:checked').forEach(cb => {
        const campId = parseInt(cb.value);
        
        // Guardamos el ID de la campaña en nuestra lista
        idsCampaniasActualizadas.push(campId);

        // Intentamos ubicar el subpanel de tiendas que le pertenece a esta campaña concreta
        const subPanel = document.getElementById(`tiendas-campania-panel-${campId}`);
        if (subPanel) {
            // Si el subpanel existe, extraemos solo las tiendas marcadas dentro de esa campaña en específico
            const checksTiendas = subPanel.querySelectorAll('.check-tienda-sub:checked');
            
            // Mapeamos los elementos del NodeList para guardarlos como un array plano de IDs enteros
            tiendasPorCampaniaActualizadas[campId] = Array.from(checksTiendas).map(tcb => parseInt(tcb.value));
        }
    });

    // Estructuramos el objeto completo consolidado (payload) con los datos del formulario normalizados en mayúsculas
    const objetoUpdate = {
        nombre: document.getElementById('titulo-colaborador').value.trim().toUpperCase(),
        estadoActivo: document.getElementById('check-campania').checked,
        observaciones: document.getElementById('edit-observaciones').value.trim(),
        calle: document.getElementById('edit-calle').value.trim().toUpperCase(),
        numero: parseInt(document.getElementById('edit-numero').value),
        nombreLocalidad: document.getElementById('edit-localidad').value.trim().toUpperCase(),
        numeroCP: document.getElementById('edit-cp').value.trim(),
        nombreZonaGeografica: (document.getElementById('edit-zona').value || "").trim().toUpperCase() || null,
        esCapital: document.getElementById('check-es-capital-panel').checked,
        nombreDistrito: (document.getElementById('edit-distrito').value || "").trim().toUpperCase() || null,
        idsCampanias: idsCampaniasActualizadas,
        tiendasPorCampania: tiendasPorCampaniaActualizadas,
        responsables: responsables
    };

    // Intentamos realizar la operación asíncrona de guardado mediante la capa de servicios
    try {
        // Enviamos la petición de actualización a la API pasándole el ID correspondiente y el payload estructurado
        await apiService.actualizarEntidad(idEntidad, objetoUpdate);

        // Extraemos los datos viejos que teníamos en cache local dentro de la sesión actual
        const colabLocal = JSON.parse(sessionStorage.getItem("colaboradorSeleccionado"));
        
        // Fusionamos usando spread options el estado viejo del colaborador con los nuevos cambios confirmados por la API
        const nuevoColab = { ...colabLocal, ...objetoUpdate };
        
        // Sincronizamos las claves de las propiedades mapeadas para que mantengan los nombres de propiedades originales
        nuevoColab.localidadNombre = objetoUpdate.nombreLocalidad;
        nuevoColab.zonaNombre = objetoUpdate.nombreZonaGeografica;
        nuevoColab.distritoNombre = objetoUpdate.nombreDistrito;
        nuevoColab.codigoPostal = objetoUpdate.numeroCP;

        // Actualizamos nuestra sesión local sobreescribiendo el JSON actualizado para que impacte el resto de vistas de inmediato
        sessionStorage.setItem("colaboradorSeleccionado", JSON.stringify(nuevoColab));

        // Notificamos un alert nativo de éxito total
        alert("Colaborador actualizado correctamente");
        
        // NOTIFICACIÓN INTER-FRAME: Emitimos una señal por nuestro canal de radio para alertar que la tabla base necesita re-renderizarse
        canalComunicacion.postMessage('recargar-tabla');
        
        // Devolvemos el formulario a su modo lectura original deshabilitando los inputs
        toggleModoEdicion();
        
    } catch (error) {
        // CAZAMOS TAMBIÉN AQUÍ LAS VALIDACIONES CONTROLADAS EN LA EDICIÓN:
        // Gestionamos errores específicos de restricciones de negocio de la base de datos (Unique Keys, duplicados)
        if (error.message && (error.message.includes("Este teléfono ya está asociado") || error.message.includes("Contacto_telefono_key"))) {
            alert("⚠️ Este teléfono ya está asociado a otro usuario");
        } else if (error.message && error.message.includes("dirección a la que la has asociado ya existe")) {
            alert("⚠️ No puedes actualizar a esta dirección porque ya está asignada a otra entidad");
        } else {
            // Si ocurre cualquier error imprevisto o ajeno a negocio, informamos con el mensaje nativo recibido
            alert("Error al actualizar: " + error.message);
        }
    }
}

// Función utilitaria para extraer una lista ordenada de enteros con los valores de los checkboxes marcados en un div contenedor
function obtenerChecksMarcados(idContenedor) {
    // Obtenemos la referencia del contenedor del DOM usando su identificador único
    const contenedor = document.getElementById(idContenedor);
    
    // Localizamos exclusivamente los elementos de tipo checkbox que tengan el estado activo (:checked)
    const checks = contenedor.querySelectorAll('input[type="checkbox"]:checked');
    
    // Transformamos la colección de nodos en un array real de JS y parseamos cada string de valor a tipo entero
    return Array.from(checks).map(cb => parseInt(cb.value));
}

// Función encargada del cierre limpio del panel lateral y de coordinar los estados entre frames jerárquicos de la página web
function cerrarPanelLateral() {
    // Verificamos si existe un entorno jerárquico superior (ventana padre), esencial al trabajar empotrados en un iframe
    if (window.parent) {
        // Buscamos el elemento iframe correspondiente al menú lateral en la estructura de la ventana del padre
        const iframeMenu = window.parent.document.querySelector('.menu-lateral-iframe');
        
        // Si el frame existe, lo redirigimos para recargar su vista por defecto
        if (iframeMenu) iframeMenu.src = '../MenuLateral/menu-lateral.html';
        
        // 🌟 DOBLE BLINDAJE INTER-FRAME: Emitimos por canal de radio y por mensaje de ventana jerárquico
        // Lanzamos una señal mediante BroadcastChannel para que los componentes del mismo dominio limpien los botones activos
        canalComunicacion.postMessage('resetear-boton-modificar');
        
        // Enviamos un mensaje de ventana seguro directamente a la ventana padre para desactivar los listeners globales del botón Modificar
        window.parent.postMessage('resetear-boton-modificar', '*');
    }
}
