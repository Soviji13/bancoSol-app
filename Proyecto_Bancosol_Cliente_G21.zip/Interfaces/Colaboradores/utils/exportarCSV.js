/**
 * Lógica para exportar los datos de la tabla de colaboradores a un archivo CSV funcional.
 * Este script se comunica con la caché de datos de conexionApiTabla.js.
 */

document.addEventListener('DOMContentLoaded', () => {
    // Localizamos el botón con la clase .csv que ya tienes en el HTML
    const btnCsv = document.querySelector('.csv');
    
    // Si el botón realmente se encuentra renderizado en el DOM de la página actual:
    if (btnCsv) {
        // Mejoramos la experiencia de usuario (UI) dándole un cursor de tipo mano interactiva
        btnCsv.style.cursor = 'pointer';
        // Le asignamos un tooltip nativo para que el usuario sepa qué hace al pasar el ratón por encima
        btnCsv.title = 'Descargar lista actual de colaboradores en CSV';
        
        // Añadimos el "escuchador" de eventos para interceptar el clic de exportación
        btnCsv.addEventListener('click', () => {
            // Verificamos si existe la variable global colaboradoresCache (definida en conexionApiTabla.js) y si contiene registros cargados
            if (typeof colaboradoresCache !== 'undefined' && colaboradoresCache.length > 0) {
                // Si la caché está viva y tiene datos, disparamos la función principal de exportación
                exportarACsv(colaboradoresCache);
            } else {
                // Si el usuario intenta exportar con la tabla vacía, le frenamos con un alert informativo
                alert("⚠️ No hay datos cargados en la tabla para exportar. Por favor, asegúrate de que la tabla muestra colaboradores.");
            }
        });
    }
});

/**
 * Transforma los objetos de la caché en un formato CSV y lanza la descarga.
 * datos - El array de colaboradores (colaboradoresCache).
 */
function exportarACsv(datos) {
    // Definir las cabeceras (Nombres de las columnas)
    // Inicializamos un array plano con las etiquetas literales que irán en la primera fila de nuestro Excel
    const cabeceras = [
        "ID", 
        "Nombre de la Entidad", 
        "Estado", 
        "Domicilio Completo", 
        "Localidad", 
        "Código Postal", 
        "Responsable Principal", 
        "Email Responsable", 
        "Teléfono Responsable", 
        "Tiendas Asignadas", 
        "Campañas",
        "Observaciones"
    ];

    // Procesar cada fila de datos
    // Recorremos el array de colaboradores de la caché para transformar cada objeto en una línea de texto CSV válida
    const filasCsv = datos.map(c => {
        // Buscamos al contacto que esté marcado explícitamente como el gestor o encargado principal
        const principal = (c.responsables || []).find(r => r.esPrincipal) || {};
        
        // Unimos las sublistas de nombres (tanto de tiendas como de campañas) usando un "pipe" como separador visual interno
        const tiendasStr = (c.nombresTiendas || []).join(" | ");
        const campaniasStr = (c.nombresCampanias || []).join(" | ");

        // Función auxiliar para sanear los strings: duplica las comillas internas (estándar CSV) y envuelve todo el campo entre comillas dobles
        const limpiar = (texto) => (texto ? `"${texto.toString().replace(/"/g, '""')}"` : '""');

        // Mapeamos los campos del objeto en el orden exacto de las cabeceras y los concatenamos mediante comas simples
        return [
            c.id,
            limpiar(c.nombre),
            c.estadoActivo ? "ACTIVO" : "INACTIVO",
            limpiar(c.domicilioCompleto),
            limpiar(c.localidadNombre),
            limpiar(c.codigoPostal),
            limpiar(principal.nombre),
            limpiar(principal.email),
            limpiar(principal.telefono),
            limpiar(tiendasStr),
            limpiar(campaniasStr),
            limpiar(c.observaciones)
        ].join(",");
    });

    // Crear el contenido final con el BOM (Byte Order Mark)
    // Esto es imporyantísimo para que Excel reconozca tildes, la 'ñ' y caracteres españoles correctamente.
    const BOM = "\uFEFF";

    // Unimos los títulos y la colección de líneas de datos formateadas usando saltos de línea estándar (\n)
    const contenidoFinal = BOM + cabeceras.join(",") + "\n" + filasCsv.join("\n");

    // Crear el archivo (Blob) y el enlace de descarga
    // Nota: unescape(encodeURIComponent()) ayuda con la codificación si el navegador es antiguo, 
    // pero el BOM suele bastar. Mantenemos tu línea de compatibilidad antigua intacta sin tocar:
    const blob = new Blob([unescape(encodeURIComponent(contenidoFinal))], { type: 'text/csv;charset=utf-8;' });
    
    // Instanciamos el Blob definitivo inyectándole directamente el contenido estructurado en formato UTF-8
    const blobFinal = new Blob([contenidoFinal], { type: 'text/csv;charset=utf-8;' });
    // Fabricamos una URL virtual y temporal en la memoria del navegador que apunta al archivo binario recién creado
    const url = URL.createObjectURL(blobFinal);
    
    // Creamos un elemento 'a' (enlace hpervínculo) fantasma directamente desde código
    const link = document.createElement("a");
    // Capturamos el timestamp actual y extraemos los primeros 10 caracteres para disponer de la fecha en formato AAAA-MM-DD
    const fecha = new Date().toISOString().slice(0, 10);
    
    // Seteamos la URL del objeto en el atributo de navegación del enlace
    link.setAttribute("href", url);
    // Configuramos el nombre de salida del archivo concatenando el prefijo del proyecto y la fecha calculada
    link.setAttribute("download", `bancosol_colaboradores_${fecha}.csv`);
    // Ocultamos el elemento visualmente mediante CSS para que no altere la maquetación de la app
    link.style.visibility = 'hidden';
    
    // Inyectamos temporalmente el enlace en el nodo body para que el navegador lo considere operativo
    document.body.appendChild(link);
    // Forzamos programáticamente el evento click para hacer saltar la ventana de descarga del navegador del usuario
    link.click();
    // Retiramos el elemento fantasma del DOM inmediatamente después de haber simulado la pulsación
    document.body.removeChild(link);
    
    // Revocamos y destruimos la URL temporal del sistema para liberar recursos de memoria del cliente
    URL.revokeObjectURL(url);
}