//broadcast channel explicado en tienda.js
const canalComunicacion = new BroadcastChannel('bancosol_channel');

const API_BASE = "http://localhost:8080/api";

async function fetchSafe(url) {
    try {
        const r = await fetch(url);
        if (!r.ok) return [];
        const d = await r.json();
        return Array.isArray(d) ? d : [];
    } catch (e) { 
        return []; 
    }
}

// pantalla de carga
function toggleLoader(mostrar) {
    let loader = document.getElementById('loading-overlay');
    if (mostrar && !loader) {
        loader = document.createElement('div');
        loader.id = 'loading-overlay';
        loader.className = 'loading-overlay';
        loader.innerHTML = `<div class="spinner"></div><div class="loading-text">Cargando datos... Por favor, espere</div>`;
        document.body.appendChild(loader);
    }
    if (loader) loader.style.display = mostrar ? 'flex' : 'none';
}

//cuando cargue el html encendemos el loader, pedimos los datos y preparamos los botones
document.addEventListener('DOMContentLoaded', async () => {
    toggleLoader(true);
    await cargarFiltrosMaestros(); //esperamos a q bajen todos los desplegables del back

    // mapeamos los clics de los botones a sus funciones
    document.getElementById('filtro-localidad').addEventListener('change', alternarDistrito);
    document.getElementById('btn-aplicar-filtros').onclick = enviarFiltros;
    document.getElementById('btn-limpiar-filtros').onclick = limpiarFiltros;
    document.getElementById('btn-cerrar-filtros').onclick = cerrarPanel;
    
    toggleLoader(false); // apagamos el spinner cuando todo esta listo
});


async function cargarFiltrosMaestros() {
    const [cadenas, localidades, distritos, zonas, entidades, responsables] = await Promise.all([
        fetchSafe(`${API_BASE}/cadenas`),
        fetchSafe(`${API_BASE}/localidades`),
        fetchSafe(`${API_BASE}/distritos`),
        fetchSafe(`${API_BASE}/zonas-geograficas`),
        fetchSafe(`${API_BASE}/entidades`),
        fetchSafe(`${API_BASE}/responsables-tiendas`)
    ]);


    poblarSelect('filtro-cadena', cadenas);
    poblarSelect('filtro-localidad', localidades);
    poblarSelect('filtro-distrito', distritos);
    poblarSelect('filtro-zona', zonas);
    poblarSelect('filtro-colaborador', entidades);
    poblarSelect('filtro-responsable', responsables);
}

//funcion aux para rellenar los desplegables del tiron sin repetir codigo
function poblarSelect(idSelect, lista) {
    const el = document.getElementById(idSelect);
    if (!el) return;
    lista.forEach(item => {
        // miramos q propiedad tiene el texto (puede llamarse nombre, codigo o venir solo el id) dependiendo del caso se usa para una cosa o otra
        const nombreText = item.nombre || item.codigo || item.id;
        const opt = new Option(nombreText, item.id);
        el.add(opt);
    });
}

//si malaga capital mostramos el desplegable de distrito, si no oculto
function alternarDistrito() {
    const selectLoc = document.getElementById('filtro-localidad');
    const bloqueDistrito = document.getElementById('bloque-distrito');
    const txtSelect = selectLoc.options[selectLoc.selectedIndex]?.text.toUpperCase() || "";

    if (txtSelect.includes("MÁLAGA") || txtSelect.includes("MALAGA")) {
        bloqueDistrito.classList.remove("oculto");
    } else {
        bloqueDistrito.classList.add("oculto");
        document.getElementById('filtro-distrito').value = ""; //vaciar para q no mande basura al back!!!!
    }
}

//empaquetamos lo q ha elegido el usuario y mandar por el canal
function enviarFiltros() {
   
    const campaniaActivaRadio = document.querySelector('input[name="filtro-campania-activa"]:checked').value;
    const franquiciaRadio = document.querySelector('input[name="filtro-franquicia"]:checked').value;

    //montamos el objeto json q espera la tabla principal para filtrar
    const filtros = {
        nombre: document.getElementById('filtro-nombre').value.trim(),
        cadenaId: document.getElementById('filtro-cadena').value,
        localidadId: document.getElementById('filtro-localidad').value,
        distritoId: document.getElementById('filtro-distrito').value,
        zonaGeoId: document.getElementById('filtro-zona').value,
        colaboradorId: document.getElementById('filtro-colaborador').value,
        responsableTiendaId: document.getElementById('filtro-responsable').value,
        
        participaActiva: campaniaActivaRadio === 'SI' ? true : (campaniaActivaRadio === 'NO' ? false : null),
        esFranquicia: franquiciaRadio === 'SI' ? true : (franquiciaRadio === 'NO' ? false : null)
    };

    // disparamos el evento para q tiendas.js lo escuche con el .onmessage y refresque la tabla
    canalComunicacion.postMessage({ type: 'aplicar-filtros-tiendas', filtros });
}

//vaciamos todos los desplegables etc y mandamos aviso a tabla de q hemos reseteado
function limpiarFiltros() {
    document.getElementById('filtro-nombre').value = '';
    document.getElementById('filtro-cadena').value = '';
    document.getElementById('filtro-localidad').value = '';
    document.getElementById('filtro-distrito').value = '';
    document.getElementById('filtro-zona').value = '';
    document.getElementById('filtro-colaborador').value = '';
    document.getElementById('filtro-responsable').value = '';
    
    document.querySelector('input[name="filtro-campania-activa"][value="TODAS"]').checked = true;
    document.querySelector('input[name="filtro-franquicia"][value="TODAS"]').checked = true;
    
    //esconder distrito por si acaso se quedo abierto
    document.getElementById('bloque-distrito').classList.add("oculto");
    
    enviarFiltros(); //mandamos la orden vacia para q la tabla quite los filtros
}

//x para cerrar el panel y q el iframe cargue el menu original
function cerrarPanel() {
    if (window.parent) {
        const iframeMenu = window.parent.document.querySelector('.menu-lateral-iframe');
        if (iframeMenu) iframeMenu.src = '../MenuLateral/menu-lateral.html';
    }
}