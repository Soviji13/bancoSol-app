// FUNCIONES "GLOBALES" (por ahora loader)

// Instanciamos el canal de comunicación una sola vez para toda la app
export const canalComunicacion = new BroadcastChannel('bancosol_channel');

// Función genérica para mostrar/ocultar el loader
export function toggleLoader(mostrar) { 

    // Obtenemos el elemento de loading 
    let loader = document.getElementById('loading-overlay'); 

    // Si no existía y se quiere msotrar (primera pasada)
    if (mostrar && !loader) 
    { 
        // Creamos el loader 
        loader = document.createElement('div'); 
        loader.id = 'loading-overlay'; 
        loader.className = 'loading-overlay'; 
        loader.innerHTML = ` 
        <div class="spinner"></div> 
        <div class="loading-text">Cargando datos... Por favor, espere</div> 
        `; 

        // Lo añadimos al documento 
        document.body.appendChild(loader); 
    } 

    // Si existía 
    if (loader) 
    { 
        // Si se desea mostrar
        loader.style.display = mostrar ? 'flex' : 'none'; 
    } 
}