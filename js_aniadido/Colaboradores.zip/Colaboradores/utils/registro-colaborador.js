import { apiService } from './apiService.js';

// VARIABLES GLOBALES
let contadorResponsables = 0;
let mapaGeografico = [];

document.addEventListener('DOMContentLoaded', () => {
    cargarOpcionesRegistro();

    // 1. Escuchar cambio de CP
    const inputCP = document.querySelector('input[name="numeroCP"]');
    if (inputCP) inputCP.addEventListener('change', manejarAutocompletadoCP);

    // 2. Escuchar el checkbox de Capital
    const checkCapital = document.getElementById('check-es-capital');
    if (checkCapital) {
        checkCapital.addEventListener('change', function() {
            toggleDistrito(this);
        });
    }

    // 3. Botón Abrir Registro
    const btnAbrir = document.getElementById('btn-abrir-registro');
    if (btnAbrir) {
        btnAbrir.onclick = () => {
            const contenedorTabla = document.querySelector('.contenedor-tabla-scroll');
            const modal = document.getElementById('modal-registro');
            const avisoBorrado = document.getElementById('aviso-borrado');

            if (contenedorTabla) contenedorTabla.style.display = 'none';
            if (avisoBorrado) avisoBorrado.style.display = 'none';

            document.querySelector('.pie-pagina').style.display = 'none';

            modal.classList.add('v-sustitucion');
            modal.style.display = 'block';

            cargarOpcionesRegistro(); 
            const contenedor = document.getElementById('contenedor-responsables');
            if (contenedor.children.length === 0) agregarBloqueResponsable();
            
            window.scrollTo(0, 0);
        };
    }
});

// Función para volver a la tabla
function cerrarModalRegistro() {
    const contenedorTabla = document.querySelector('.contenedor-tabla-scroll');
    const modal = document.getElementById('modal-registro');

    modal.style.display = 'none';
    modal.classList.remove('v-sustitucion');

    if (contenedorTabla) contenedorTabla.style.display = 'block';

    document.querySelector('.pie-pagina').style.display = 'flex';
}
// La exponemos a window por si se llama desde un botón HTML con onclick
window.cerrarModalRegistro = cerrarModalRegistro;

async function cargarOpcionesRegistro() {
    try {
        // 🔄 ¡CONECTADO AL SERVICIO! Ya no dependemos de API_BASE ni de hacer .json() manual
        const [resTiendas, resCampanias, resCps, resLocs, resDirs, resDists, resCoords, resZonas] = await Promise.all([
            apiService.obtenerTiendas(),
            apiService.obtenerCampanias(),
            apiService.obtenerCodigosPostales(),
            apiService.obtenerLocalidades(),
            apiService.obtenerDirecciones(),
            apiService.obtenerDistritos(),
            apiService.obtenerCoordinadores(),
            apiService.obtenerZonasGeograficas()
        ]);

        // Llenar datalists
        document.getElementById('lista-localidades').innerHTML = resLocs.map(l => `<option value="${l.nombre}">`).join('');
        document.getElementById('lista-cps').innerHTML = resCps.map(cp => `<option value="${cp.codigo}">`).join('');
        document.getElementById('lista-distritos').innerHTML = resDists.map(d => `<option value="${d.nombre}">`).join('');
        document.getElementById('lista-zonas').innerHTML = resZonas.map(z => `<option value="${z.nombre}">`).join('');

        // Campañas
        const contCampaniasReg = document.getElementById('check-campanias');
        
        contCampaniasReg.style.display = 'flex';
        contCampaniasReg.style.flexDirection = 'column';
        contCampaniasReg.style.width = '100%';
        contCampaniasReg.style.gap = '12px';
        contCampaniasReg.style.boxSizing = 'border-box';

        contCampaniasReg.innerHTML = resCampanias.map(c => `
            <div class="campania-block-item" style="width: 100%; box-sizing: border-box; background: #f8fafc; padding: 12px; border-radius: 6px; border: 1px solid #e2e8f0; display: block;">
                <label style="font-weight: bold; color: var(--color-principal); cursor: pointer; display: flex; align-items: center; gap: 10px; width: 100%; box-sizing: border-box;">
                    <input type="checkbox" value="${c.id}" class="check-campania-master" onchange="toggleTiendasCampania(this, ${c.id})" style="flex-shrink: 0; width: 16px; height: 16px; margin: 0;">
                    <span style="line-height: 1.4; flex: 1; white-space: normal; text-align: left; word-break: break-word; font-size: 1.05em;">${c.nombre}</span>
                </label>
                
                <div id="tiendas-campania-${c.id}" style="display: none; margin-left: 20px; border-left: 2px solid #cbd5e1; padding-left: 14px; margin-top: 10px; width: calc(100% - 20px); box-sizing: border-box; max-height: 200px; overflow-y: auto;">
                    <span style="font-size: 0.85em; color: #64748b; margin-bottom: 8px; display: block; font-weight: 500; text-align: left;">Selecciona las tiendas asignadas para esta campaña:</span>
                    ${resTiendas.map(t => `
                        <label style="display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px; font-size: 0.9em; cursor: pointer; color: #334155; width: 100%; box-sizing: border-box;">
                            <input type="checkbox" value="${t.id}" class="check-tienda-sub" style="margin-top: 3px; flex-shrink: 0; width: 14px; height: 14px; margin-left: 0;">
                            <span style="flex: 1; white-space: normal; text-align: left; line-height: 1.3; word-break: break-word;">${t.nombre}</span>
                        </label>
                    `).join('')}
                </div>
            </div>
        `).join('');

        // Exponemos la función al HTML
        window.toggleTiendasCampania = function(checkbox, campId) {
            const div = document.getElementById(`tiendas-campania-${campId}`);
            if (div) div.style.display = checkbox.checked ? 'block' : 'none';
            // Si desmarca la campaña, limpiamos las tiendas que tuviera elegidas
            if (!checkbox.checked) div.querySelectorAll('input').forEach(i => i.checked = false);
        };

        // CONSTRUCCIÓN DEL MAPA INTELIGENTE
        mapaGeografico = resDirs.map(dir => {
            const cpObj = resCps.find(c => c.id === dir.codigoPostalId);
            const locObj = resLocs.find(l => l.id === dir.localidadId);
            const zonaObj = locObj ? resZonas.find(z => z.id === locObj.zonaGeoId) : null;
            const distObj = resDists.find(d => d.id === dir.distritoId);
            
            return {
                codigo: cpObj ? cpObj.codigo : null,
                localidad: locObj ? locObj.nombre : '',
                zonaNombre: zonaObj ? zonaObj.nombre : '', 
                distrito: distObj ? distObj.nombre : '',
                esCapital: dir.esCapital
            };
        }).filter(item => item.codigo);

        const selectCoords = document.getElementById('select-coordinadores');
        selectCoords.innerHTML = '<option value="">Seleccione un coordinador...</option>' + 
            resCoords.map(c => `<option value="${c.id}">${c.nombre}</option>`).join('');

    } catch (error) {
        console.error("Error cargando el motor:", error);
    }
}

function toggleDistrito(checkbox) {
    const divDistrito = document.getElementById('campo-distrito');
    if (divDistrito) {
        divDistrito.style.display = checkbox.checked ? 'block' : 'none';
        if (!checkbox.checked) divDistrito.querySelector('input').value = '';
    }
}

function manejarAutocompletadoCP(e) {
    const cpIntroducido = e.target.value;
    const coincidencia = mapaGeografico.find(m => m.codigo == cpIntroducido);

    if (coincidencia) {
        document.querySelector('input[name="nombreLocalidad"]').value = coincidencia.localidad;
        const checkCapital = document.getElementById('check-es-capital');
        checkCapital.checked = coincidencia.esCapital;
        toggleDistrito(checkCapital);

        if (coincidencia.esCapital && coincidencia.distrito) {
            document.querySelector('input[name="nombreDistrito"]').value = coincidencia.distrito;
        }

        const inputZona = document.getElementById('input-zona');
        if (coincidencia.zonaNombre) {
            inputZona.value = coincidencia.zonaNombre;
            inputZona.readOnly = true; 
            inputZona.style.backgroundColor = "#e9ecef";
        } else {
            inputZona.value = "";
            inputZona.readOnly = false;
            inputZona.style.backgroundColor = "#fff";
        }
    }
}

function agregarBloqueResponsable() {
    const contenedor = document.getElementById('contenedor-responsables');
    const index = contadorResponsables++;
    
    const html = `
        <div class="responsable-card" id="resp-${index}">
            <div class="card-header">
                <h4>Responsable #${index + 1}</h4>
                <button type="button" class="btn-eliminar-resp" onclick="this.closest('.responsable-card').remove()">Eliminar</button>
            </div>
            <div class="form-grid-resp">
                <input type="text" placeholder="Nombre completo" class="r-nombre" required>
                <input type="email" placeholder="Email" class="r-email" required>
                <input type="tel" placeholder="Teléfono" class="r-telefono" required>
                <div class="radio-group">
                    <label><input type="radio" name="esPrincipal" class="r-principal" ${index === 0 ? 'checked' : ''}> ¿Principal?</label>
                </div>
                <hr>
                <input type="text" placeholder="Username (Email)" class="r-user" required>
                <input type="password" placeholder="Contraseña" class="r-pass" required>
            </div>
        </div>
    `;
    contenedor.insertAdjacentHTML('beforeend', html);
}
// La exponemos a window por si tienes un botón de "Añadir Responsable" con onclick en el HTML
window.agregarBloqueResponsable = agregarBloqueResponsable;

document.getElementById('form-registro-entidad').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    try {
        const formData = new FormData(e.target);
        const responsables = Array.from(document.querySelectorAll('.responsable-card')).map(card => ({
            nombre: card.querySelector('.r-nombre').value,
            email: card.querySelector('.r-email').value,
            telefono: card.querySelector('.r-telefono').value,
            esPrincipal: card.querySelector('.r-principal').checked,
            username: card.querySelector('.r-user').value,
            password: card.querySelector('.r-pass').value
        }));

        const idsCampanias = [];
        const tiendasPorCampania = {};
        
        // Extraemos de forma jerárquica estricta
        document.querySelectorAll('.check-campania-master:checked').forEach(cb => {
            const cId = parseInt(cb.value);
            idsCampanias.push(cId);
            
            const checksTiendas = document.querySelectorAll(`#tiendas-campania-${cId} .check-tienda-sub:checked`);
            tiendasPorCampania[cId] = Array.from(checksTiendas).map(t => parseInt(t.value));
        });

        const objetoFinal = {
            nombre: formData.get('nombre'),
            estadoActivo: formData.get('estadoActivo') === 'on',
            observaciones: formData.get('observaciones'),
            calle: formData.get('calle'),
            numero: parseInt(formData.get('numero')),
            esCapital: formData.get('esCapital') === 'on',
            nombreLocalidad: formData.get('nombreLocalidad'),
            numeroCP: formData.get('numeroCP'),
            nombreZonaGeografica: formData.get('nombreZonaGeografica'),
            nombreDistrito: formData.get('nombreDistrito') || null,
            responsables: responsables,
            idsCampanias: idsCampanias,             // 🌟 CORREGIDO: Usamos la lista limpia
            tiendasPorCampania: tiendasPorCampania, // 🌟 CORREGIDO: Mapeo estructurado
            idCoordinador: parseInt(formData.get('idCoordinador'))
        };

        // 🔄 Envío limpio a través del servicio
        await apiService.crearEntidad(objetoFinal);
        alert("¡Entidad creada con éxito!");
        window.location.reload();

    } catch (error) {
        console.error("Fallo crítico:", error);
        
        if (error.message && error.message.includes("dirección a la que la has asociado ya existe")) {
            alert("⚠️ No puedes añadir esta entidad colaboradora porque la dirección a la que la has asociado ya existe");
        } else if (error.message && (error.message.includes("Este teléfono ya está asociado") || error.message.includes("Contacto_telefono_key"))) {
            // 🌟 CAZAMOS EL ERROR DE TELÉFONO
            alert("⚠️ Este teléfono ya está asociado a otro usuario");
        } else {
            alert("🚨 Error al guardar: " + error.message);
        }
    }
});

function obtenerChecksMarcados(idContenedor) {
    const contenedor = document.getElementById(idContenedor);
    if (!contenedor) return [];
    const checks = contenedor.querySelectorAll('input[type="checkbox"]:checked');
    return Array.from(checks).map(cb => parseInt(cb.value));
}