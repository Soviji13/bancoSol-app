// panelFiltros.js - ¡VERSIÓN CHECKBOX SINCRONIZADA!
import { apiService } from './apiService.js';
import { canalComunicacion } from './utils.js';

document.addEventListener('DOMContentLoaded', async () => {
    await cargarFiltrosMaestros();

    document.getElementById('btn-aplicar-filtros').onclick = enviarFiltros;
    document.getElementById('btn-limpiar-filtros').onclick = limpiarFiltros;
    
    const btnCerrar = document.getElementById('btn-cerrar-filtros');
    if (btnCerrar) {
        btnCerrar.onclick = cerrarPanel;
    }
});

async function cargarFiltrosMaestros() {
    const datosColabs = JSON.parse(sessionStorage.getItem("colaboradoresCache")) || [];
    const selectLoc = document.getElementById('filtro-localidad');
    const localidades = [...new Set(datosColabs.map(c => c.localidadNombre))].filter(Boolean).sort();
    
    localidades.forEach(loc => {
        selectLoc.add(new Option(loc, loc));
    });

    // Sincronizamos el estado del checkbox si la vista agrupada estaba guardada en memoria
    const mostrarTodasAlInicio = localStorage.getItem("mostrarTodasCampanias") === "true";
    const checkTodas = document.getElementById('filtro-todas-campanias');
    if (checkTodas) {
        checkTodas.checked = mostrarTodasAlInicio;
    }
}

function enviarFiltros(e) {
    if (e && typeof e.preventDefault === 'function') {
        e.preventDefault();
    }

    // 🌟 ENVIAMOS EL CONTRATO CORRECTO: f.todasCampanias como boolean
    const filtros = {
        tienda: document.getElementById('filtro-tienda').value.trim().toUpperCase(),
        localidad: document.getElementById('filtro-localidad').value,
        todasCampanias: document.getElementById('filtro-todas-campanias').checked, 
        soloCapital: document.getElementById('filtro-capital').checked,
        soloActiva: document.getElementById('filtro-activa').checked
    };

    canalComunicacion.postMessage({ type: 'aplicar-filtros', filtros });
}

function limpiarFiltros(e) {
    if (e && typeof e.preventDefault === 'function') e.preventDefault();
    
    document.getElementById('filtro-tienda').value = '';
    document.getElementById('filtro-localidad').value = '';
    document.getElementById('filtro-todas-campanias').checked = false;
    document.getElementById('filtro-capital').checked = false;
    document.getElementById('filtro-activa').checked = false;
    enviarFiltros();
}

function cerrarPanel() {
    if (window.parent) {
        const iframeMenu = window.parent.document.querySelector('.menu-lateral-iframe');
        if (iframeMenu) iframeMenu.src = '../MenuLateral/menu-lateral.html';
    }
}