// utils/conexionApiTabla.js
import { apiService } from './apiService.js';
import { canalComunicacion, toggleLoader } from './utils.js';

// VARIABLES GLOBALES Y CACHÉ
let colaboradoresCache = [];
let colaboradoresOriginales = [];
let campaniasCache = []; 
let modoEliminarActivo = false;
let idCampaniaVisualizada = 1; 
let idColaboradorActivo = null; 

// 🌟 MEMORIA DE FILTROS: Estructura base para persistir la búsqueda entre recargas de campaña
let filtrosActivos = {
    tienda: "",
    localidad: "",
    todasCampanias: false,
    soloCapital: false,
    soloActiva: false
};

document.addEventListener('DOMContentLoaded', () => {
    cargarTablaDinamica();

    const tbody = document.querySelector('#tabla-body');
    const btnEliminar = document.getElementById('btn-eliminar-colaborador');
    const aviso = document.getElementById('aviso-borrado');
    const tabla = document.querySelector('table');

    tbody.addEventListener('dblclick', (event) => {
        const fila = event.target.closest('tr');
        if (fila && fila.dataset.id && !modoEliminarActivo) {
            abrirDetalleColaborador(fila.dataset.id);
        }
    });

    tbody.addEventListener('click', async (event) => {
        if (!modoEliminarActivo) return;
        const fila = event.target.closest('tr');
        if (!fila || !fila.dataset.id) return; 
        
        const idEntidad = fila.dataset.id;
        const nombreColaborador = fila.cells[0].innerText;

        if (confirm(`⚠️ ¿ELIMINAR PERMANENTEMENTE? \nSe borrará "${nombreColaborador}".`)) {
            try {
                await apiService.eliminarEntidad(idEntidad);
                alert("Entidad Query eliminada correctamente.");
                fila.remove(); 
                desactivarModoEliminar(aviso, tabla, btnEliminar);
            } catch (error) { 
                alert("Error al eliminar la entidad.");
            }
        }
    });

    if (btnEliminar) {
        btnEliminar.addEventListener('click', () => {
            modoEliminarActivo = !modoEliminarActivo;
            if (modoEliminarActivo) {
                aviso.style.display = 'flex';
                tabla.classList.add('modo-borrado-activo');
                btnEliminar.style.backgroundColor = "#e02424";
                btnEliminar.style.color = "white";
            } else {
                desactivarModoEliminar(aviso, tabla, btnEliminar);
            }
        });
    }

    const btnCancelarBorrado = document.getElementById('btn-cancelar-borrado');
    if (btnCancelarBorrado) {
        btnCancelarBorrado.addEventListener('click', () => {
            desactivarModoEliminar(aviso, tabla, btnEliminar);
        });
    }

    canalComunicacion.onmessage = (event) => {
        if (event.data === 'recargar-tabla') {
            cargarTablaDinamica(); 
        } else if (event.data === 'resetear-boton-modificar') {
            idColaboradorActivo = null; 
            revalidaBotonModificar();
        } else if (event.data.type === 'aplicar-filtros') {
            aplicarFiltrosDinamicos(event.data.filtros);
        }
    };

    window.addEventListener('message', (event) => {
        if (event.data === 'resetear-boton-modificar') {
            idColaboradorActivo = null; 
            revalidaBotonModificar();
        } else if (event.data && event.data.type === 'cambiar-campania-local') {
            console.log("🎪 Cambio de campaña detectado:", event.data.campania.nombre);
            idCampaniaVisualizada = event.data.campania.id;
            
            localStorage.setItem("idCampaniaVisualizada", idCampaniaVisualizada); 
            
            // 🌟 SINCRO: Desactivamos el "Ver todas", pero PRESERVAMOS el resto de filtros activos
            filtrosActivos.todasCampanias = false;
            localStorage.setItem("mostrarTodasCampanias", "false"); 
            
            // Desmarcamos el checkbox en el panel de filtros si estuviera abierto
            const iframeMenu = window.parent?.document.querySelector('.menu-lateral-iframe') || document.querySelector('.menu-lateral-iframe');
            if (iframeMenu && iframeMenu.contentWindow) {
                const checkTodas = iframeMenu.contentWindow.document.getElementById('filtro-todas-campanias');
                if (checkTodas) checkTodas.checked = false;
            }

            document.querySelector('.encabezado h1').textContent = event.data.campania.nombre;
            cargarTablaDinamica(); 
        }
    });

    document.getElementById('filtrar').onclick = () => {
        if (window.parent) {
            const iframeMenu = window.parent.document.querySelector('.menu-lateral-iframe');
            if (iframeMenu) {
                iframeMenu.src = "../Colaboradores/panelFiltros.html"; 
            }
        }
    };
});

window.cambiarCampaniaManual = function(campania) {
    idCampaniaVisualizada = campania.id;
    localStorage.setItem("idCampaniaVisualizada", idCampaniaVisualizada); 
    filtrosActivos.todasCampanias = false;
    localStorage.setItem("mostrarTodasCampanias", "false"); 
    document.querySelector('.encabezado h1').textContent = campania.nombre;
    cargarTablaDinamica(); 
};

async function cargarTablaDinamica() {
    toggleLoader(true); 
    try {
        const [todas, campanias] = await Promise.all([
            apiService.obtenerEntidades(),
            apiService.obtenerCampanias()
        ]);
        
        colaboradoresOriginales = todas;
        campaniasCache = campanias; 
        sessionStorage.setItem("colaboradoresCache", JSON.stringify(todas));

        const guardada = localStorage.getItem("idCampaniaVisualizada");
        if (guardada) {
            idCampaniaVisualizada = parseInt(guardada);
        } else if (campanias.length > 0) {
            const campaniaActiva = campanias.find(c => c.activa === true) || campanias[0];
            idCampaniaVisualizada = campaniaActiva.id;
            localStorage.setItem("idCampaniaVisualizada", idCampaniaVisualizada);
        }

        // Sincronizamos el estado en memoria con lo almacenado en LocalStorage
        filtrosActivos.todasCampanias = localStorage.getItem("mostrarTodasCampanias") === "true";

        const def = campanias.find(c => c.id === idCampaniaVisualizada);
        if (def && localStorage.getItem("mostrarTodasCampanias") !== "true") {
            document.querySelector('.encabezado h1').textContent = def.nombre;
        }

        // 🌟 RE-APLICAMOS EL FILTRO ACTIVO DIRECTAMENTE (Mantiene las búsquedas vivas tras cambios)
        aplicarFiltrosDinamicos(filtrosActivos);

    } catch (error) { 
        console.error("🚨 Fallo al cargar la tabla:", error);
    } finally {
        toggleLoader(false); 
    }
}

function aplicarFiltrosDinamicos(f) {
    filtrosActivos = f; // Guardamos el estado actual en la memoria del módulo
    
    let contadorFiltros = 0;
    if (f.tienda) contadorFiltros++;
    if (f.localidad) contadorFiltros++;
    if (f.todasCampanias) contadorFiltros++;
    if (f.soloCapital) contadorFiltros++;
    if (f.soloActiva) contadorFiltros++;

    const contenedorFiltro = document.querySelector('.boton-filtro');
    if (contenedorFiltro) {
        const badgeExistente = contenedorFiltro.querySelector('.badge-filtros');
        if (badgeExistente) badgeExistente.remove();

        if (contadorFiltros > 0) {
            const badge = document.createElement('span');
            badge.className = 'badge-filtros';
            badge.textContent = contadorFiltros;
            contenedorFiltro.appendChild(badge);
        }
    }

    let filtrados = colaboradoresOriginales;
    if (f.localidad) filtrados = filtrados.filter(c => c.localidadNombre === f.localidad);
    if (f.soloCapital) filtrados = filtrados.filter(c => c.esCapital === true); 
    if (f.soloActiva) filtrados = filtrados.filter(c => c.estadoActivo === true);

    localStorage.setItem("mostrarTodasCampanias", f.todasCampanias);

    const terminoTienda = f.tienda ? f.tienda.trim().toUpperCase() : "";

    if (f.todasCampanias) {
        document.querySelector('.encabezado h1').textContent = "Todas las campañas";
        if (terminoTienda) {
            filtrados = filtrados.filter(c => {
                const todasSusTiendas = c.tiendasPorCampania ? Object.values(c.tiendasPorCampania).flat() : c.nombresTiendas || [];
                return todasSusTiendas.some(t => t.toUpperCase().includes(terminoTienda));
            });
        }
        renderizarTablaAgrupadaPorCampania(filtrados, terminoTienda); 
    } else {
        const def = campaniasCache.find(c => c.id == idCampaniaVisualizada);
        if (def) document.querySelector('.encabezado h1').textContent = def.nombre;
        
        if (terminoTienda) {
            filtrados = filtrados.filter(c => {
                const tiendasDeEstaCampania = c.tiendasPorCampania ? (c.tiendasPorCampania[idCampaniaVisualizada] || []) : c.nombresTiendas || [];
                return tiendasDeEstaCampania.some(t => t.toUpperCase().includes(terminoTienda));
            });
        }
        
        const entidadesAMostrar = filtrados.filter(c => c.idsCampanias?.includes(idCampaniaVisualizada));
        renderizarFilasNormales(entidadesAMostrar);
    }

    revalidaBotonModificar();
}

function renderizarFilasNormales(datos) {
    colaboradoresCache = datos; 
    window.colaboradoresCache = datos; // 🌟 PUENTE GLOBAL MÁGICO: Hace visible la caché para exportarCSV.js
    const tbody = document.querySelector('#tabla-body');
    tbody.innerHTML = '';
    inyectarFilasEnContenedor(datos, tbody, idCampaniaVisualizada);
}

function renderizarTablaAgrupadaPorCampania(datos, textoTiendaFiltro = null) {
    colaboradoresCache = datos;
    window.colaboradoresCache = datos; // 🌟 PUENTE GLOBAL MÁGICO: Hace visible la caché para exportarCSV.js
    const tbody = document.querySelector('#tabla-body');
    tbody.innerHTML = '';

    campaniasCache.forEach(campania => {
        let colaboradoresDeEstaCampania = datos.filter(c => c.idsCampanias?.includes(campania.id));

        if (textoTiendaFiltro) {
            colaboradoresDeEstaCampania = colaboradoresDeEstaCampania.filter(c => {
                const tiendasCamp = c.tiendasPorCampania ? (c.tiendasPorCampania[campania.id] || []) : c.nombresTiendas || [];
                return tiendasCamp.some(t => t.toUpperCase().includes(textoTiendaFiltro));
            });
        }

        if (colaboradoresDeEstaCampania.length > 0) {
            const filaCabecera = document.createElement('tr');
            filaCabecera.innerHTML = `<td colspan="6" class="fila-seccion-campania"> CAMPAÑA: ${campania.nombre.toUpperCase()}</td>`;
            tbody.appendChild(filaCabecera);

            inyectarFilasEnContenedor(colaboradoresDeEstaCampania, tbody, campania.id);
        }
    });
}

function inyectarFilasEnContenedor(lista, contenedor, idCampaniaContexto) {
    lista.forEach(colab => {
        const fila = document.createElement('tr');
        fila.dataset.id = colab.id;

        const principal = colab.responsables?.find(r => r.esPrincipal);
        const contactoHtml = principal ? `${principal.nombre} <br><small>${principal.email}</small>` : "Sin contacto";
        
        const listaT = colab.tiendasPorCampania ? (colab.tiendasPorCampania[idCampaniaContexto] || []) : [...new Set(colab.nombresTiendas || [])];
        
        const tiendasHtml = `
            <div class="tiendas-resumen">${listaT[0] || '---'} ${listaT.length > 1 ? `<b>(+${listaT.length - 1})</b>` : ''}</div>
            <div class="tiendas-lista-completa" style="display: none;">
                ${listaT.map(t => `<div style="margin-bottom: 10px;">- ${t}</div>`).join('')}
            </div>
        `;

        fila.innerHTML = `
            <td>${colab.nombre}</td>
            <td>${colab.domicilioCompleto}</td>
            <td>${colab.localidadNombre}</td>
            <td>${contactoHtml}</td>
            <td>${tiendasHtml}</td>
            <td class="desplegar" onclick="desplegarTiendas(this)">&nbsp;</td>
        `;
        contenedor.appendChild(fila);
    });
}

function abrirDetalleColaborador(id) {
    const colaborador = colaboradoresCache.find(c => c.id == id);
    if (colaborador) {
        sessionStorage.setItem("colaboradorSeleccionado", JSON.stringify(colaborador));
        idColaboradorActivo = id; 
        revalidaBotonModificar();

        if (window.parent && window.parent.document) {
            const iframeMenu = window.parent.document.querySelector(".menu-lateral-iframe");
            if (iframeMenu) iframeMenu.src = "../Colaboradores/colaboradorSeleccionado.html";
        }
    }
}

function revalidaBotonModificar() {
    const btnModificar = document.getElementById('btn-modificar-colaborador');
    const iframeMenu = window.parent?.document.querySelector('.menu-lateral-iframe') || document.querySelector('.menu-lateral-iframe');

    if (btnModificar) {
        if (idColaboradorActivo !== null) {
            btnModificar.classList.replace('desactivado', 'activado');
            btnModificar.title = "Modificar los datos del colaborador seleccionado";
            btnModificar.onclick = () => {
                if (iframeMenu && iframeMenu.contentWindow) {
                    iframeMenu.contentWindow.postMessage('toggle-edicion-lateral', '*');
                    iframeMenu.style.boxShadow = "0 0 15px rgba(37, 99, 235, 0.5)";
                    setTimeout(() => iframeMenu.style.boxShadow = "none", 1000);
                }
            };
        } else {
            resetearBotonModificar();
        }
    }
}

function resetearBotonModificar() {
    const btnModificar = document.getElementById('btn-modificar-colaborador');
    if (btnModificar) {
        btnModificar.classList.replace('activado', 'desactivado');
        btnModificar.title = "Debes primero seleccionar un colaborador";
        btnModificar.onclick = null;
    }
}

function desactivarModoEliminar(aviso, tabla, btn) {
    modoEliminarActivo = false;
    if (aviso) aviso.style.display = 'none';
    if (tabla) tabla.classList.remove('modo-borrado-activo');
    if (btn) {
        btn.style.backgroundColor = ""; 
        btn.style.color = "";
    }
}

window.desplegarTiendas = function(celdaBoton) {
    const celdaTiendas = celdaBoton.previousElementSibling;
    if (!celdaTiendas) return;
    
    const resumen = celdaTiendas.querySelector('.tiendas-resumen');
    const listaCompleta = celdaTiendas.querySelector('.tiendas-lista-completa');
    
    if (resumen && listaCompleta) {
        const estaOculta = listaCompleta.style.display === 'none';
        listaCompleta.style.display = estaOculta ? 'block' : 'none';
        resumen.style.display = estaOculta ? 'none' : 'block';
        
        if (estaOculta) {
            celdaBoton.classList.add('rotado');
        } else {
            celdaBoton.classList.remove('rotado');
        }
    }
};