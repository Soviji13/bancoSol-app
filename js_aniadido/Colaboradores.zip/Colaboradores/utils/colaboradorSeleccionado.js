/*************************************************************************************
 * LÓGICA DE VER INFORMACIÓN DE UN COLABORADOR COMPLETA Y DE PODER MODIFICARLO
 *************************************************************************************/

// Importamos apiService y canalComunicación para poder acceder bien a los datos
import { apiService } from './apiService.js';
import { canalComunicacion } from './utils.js';

// Cuando se haya cargado todo el DOM estático y todos los scripts:
document.addEventListener('DOMContentLoaded', async () => {

    // 1. Cargar todas las opciones (CPs, Localidades, Tiendas, Campañas) por si se decide modificar
    await cargarListasDesplegables();

    // 2. Cargar los datos específicos del colaborador seleccionado
    cargarDatosFormulario();

    // Si la ventana recibe el evento de modificar la entidad colaboradora
    window.addEventListener('message', (event) => {
        if (event.data === 'toggle-edicion-lateral') {
            toggleModoEdicion();
        }
    });

    // Eventos sobre el menú lateral
    document.getElementById('btn-cerrar-panel')?.addEventListener('click', cerrarPanelLateral);
    document.getElementById('btn-add-contacto')?.addEventListener('click', () => renderizarBloqueContacto({}, null, true));
    document.getElementById('form-edicion-lateral')?.addEventListener('submit', guardarCambiosReales);
});

// Función para activar/desactivar el modo edición
function toggleModoEdicion() {

    // Obtenemos del documento el formulario de edición
    const form = document.getElementById('form-edicion-lateral');
    
    // Si nos encontrábamos en modo lectura, pasamos a modo edición
    if (form.classList.contains('modo-lectura')) {
        form.classList.replace('modo-lectura', 'modo-edicion');
        
        // Ponemos todos los inputs y textArea activos
        form.querySelectorAll('input, textarea').forEach(el => {
            el.removeAttribute('readonly');
            el.removeAttribute('disabled');
        });

        document.getElementById('btn-guardar-container').style.display = 'block';
        document.getElementById('btn-add-contacto-container').style.display = 'block';
        document.getElementById('edit-calle').focus();
    // Si nos encontrábamos en modo edición, pasamos a modo lectura
    } else {
        form.classList.replace('modo-edicion', 'modo-lectura');
        
        // Volvemos a reestablecer el modo de lectura únicamente
        form.querySelectorAll('input, textarea').forEach(el => {
            if (el.type === 'checkbox' || el.type === 'radio') {
                el.setAttribute('disabled', 'true');
            } else {
                el.setAttribute('readonly', 'true');
            }
        });

        // Ocultamos el botón de guardar y el de añadir nuevo responsable
        document.getElementById('btn-guardar-container').style.display = 'none';
        document.getElementById('btn-add-contacto-container').style.display = 'none';
        
        // Cargamos los datos del formulario
        cargarDatosFormulario();
    }
}

// Cargamos listas desplegables para la posible modificación
async function cargarListasDesplegables() {
    const loaderLateral = document.createElement('div');
    loaderLateral.className = 'loading-overlay';
    loaderLateral.style.position = 'absolute'; 
    loaderLateral.innerHTML = '<div class="spinner"></div>';
    document.querySelector('.panel-colaborador').appendChild(loaderLateral);

    try {
        const [resCps, resLocs, resTiendas, resCampanias, resZonas, resDists] = await Promise.all([
            apiService.obtenerCodigosPostales(),
            apiService.obtenerLocalidades(),
            apiService.obtenerTiendas(),
            apiService.obtenerCampanias(),
            apiService.obtenerZonasGeograficas(),
            apiService.obtenerDistritos()
        ]);

        document.getElementById('lista-cps-panel').innerHTML = resCps.map(cp => `<option value="${cp.codigo}">`).join('');
        document.getElementById('lista-locs-panel').innerHTML = resLocs.map(l => `<option value="${l.nombre}">`).join('');
        document.getElementById('lista-zonas-panel').innerHTML = resZonas.map(z => `<option value="${z.nombre}">`).join('');
        document.getElementById('lista-distritos-panel').innerHTML = resDists.map(d => `<option value="${d.nombre}">`).join('');

        const contTiendas = document.getElementById('check-tiendas-panel');
        contTiendas.innerHTML = resTiendas.map(t => 
            `<label><input type="checkbox" value="${t.id}" class="check-tienda-panel" disabled> ${t.nombre}</label>`
        ).join('');

        const contCampanias = document.getElementById('check-campanias-panel');
        
        // 🌟 APAGÓN DE HERENCIA HORIZONTAL: Forzamos comportamiento de columna estricta al 100%
        contCampanias.style.display = 'flex';
        contCampanias.style.flexDirection = 'column';
        contCampanias.style.width = '100%';
        contCampanias.style.gap = '12px';
        contCampanias.style.boxSizing = 'border-box';

        contCampanias.innerHTML = resCampanias.map(c => `
            <div class="campania-panel-item" style="width: 100%; box-sizing: border-box; background: #f8fafc; padding: 10px; border-radius: 6px; border: 1px solid #e2e8f0; display: block;">
                <label style="font-weight: bold; color: var(--color-principal); display: flex; align-items: center; gap: 10px; cursor: pointer; width: 100%; box-sizing: border-box;">
                    <input type="checkbox" value="${c.id}" class="check-campania-master panel-cb" disabled onchange="toggleTiendasPanel(this, ${c.id})" style="flex-shrink: 0; width: 16px; height: 16px; margin: 0;">
                    <span style="line-height: 1.4; flex: 1; white-space: normal; text-align: left; word-break: break-word;">${c.nombre}</span>
                </label>
                
                <div id="tiendas-campania-panel-${c.id}" style="display: none; margin-left: 15px; border-left: 2px solid #cbd5e1; padding-left: 12px; margin-top: 8px; width: calc(100% - 15px); box-sizing: border-box;">
                    ${resTiendas.map(t => `
                        <label style="display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px; font-size: 0.9em; cursor: pointer; color: #334155; width: 100%; box-sizing: border-box;">
                            <input type="checkbox" value="${t.id}" class="check-tienda-sub panel-cb" disabled style="margin-top: 3px; flex-shrink: 0; width: 14px; height: 14px; margin-left: 0;">
                            <span style="flex: 1; white-space: normal; text-align: left; line-height: 1.3; word-break: break-word;">${t.nombre}</span>
                        </label>
                    `).join('')}
                </div>
            </div>
        `).join('');

        window.toggleTiendasPanel = function(cb, id) {
            const div = document.getElementById(`tiendas-campania-panel-${id}`);
            if (div) div.style.display = cb.checked ? 'block' : 'none';
        };

    } catch (e) {
        console.error("Fallo al cargar datos maestros del panel", e);
    } finally {
        loaderLateral.remove();
    }
}

function cargarDatosFormulario() {

    // Obtenemos los datos de la entidad colaboradora seleccionada
    const colab = JSON.parse(sessionStorage.getItem("colaboradorSeleccionado"));

    // Si no se han podido obtener, paramos la función
    if (!colab) return;

    
    let calle = colab.calle || "";
    let numero = colab.numero || "";

    // Si no hay calle, pero sí domicilio completo, lo dividimos desde aquí
    if (!calle && colab.domicilioCompleto) {
        const partes = colab.domicilioCompleto.split(',');
        calle = partes[0] ? partes[0].trim() : "";
        numero = partes[1] ? parseInt(partes[1].trim()) : "";
    }

    // Introducimos los atributos del colaborador seleccionado en los elementos del DOM
    document.getElementById('titulo-colaborador').value = colab.nombre || "";
    document.getElementById('colaborador-id').value = colab.id;
    document.getElementById('detalle-id-display').textContent = `A${String(colab.id).padStart(5, '0')}`;
    document.getElementById('check-campania').checked = colab.estadoActivo;
    document.getElementById('edit-observaciones').value = colab.observaciones || "";
    document.getElementById('edit-calle').value = calle;
    document.getElementById('edit-numero').value = numero;
    document.getElementById('edit-localidad').value = colab.localidadNombre || "";
    document.getElementById('edit-cp').value = colab.codigoPostal || "";

    // Obtenemos las tiendas asociadas a la entidad colaboradora en la campaña
    let misTiendasNombres = [];
    if (colab.tiendasPorCampania) {
        misTiendasNombres = [...new Set(Object.values(colab.tiendasPorCampania).flat())];
    // Si no se pueden obtener, obtendremos o todas sus tiendas (sin importar la campaña) o un array vacío
    } else {
        misTiendasNombres = colab.nombresTiendas || [];
    }

    // Ponemos check las tiendas que contiene la entidad colaboradora
    document.querySelectorAll('.check-tienda-panel').forEach(cb => {
        const nombreTiendaEnPanel = cb.parentElement.textContent.trim();
        cb.checked = misTiendasNombres.includes(nombreTiendaEnPanel);
    });

    const misIdsCampanias = colab.idsCampanias || [];
    const misIdsTiendasMap = colab.idsTiendasPorCampania || {}; // El que creamos en Java!

    document.querySelectorAll('.check-campania-master').forEach(cb => {
        const campId = parseInt(cb.value);
        if (misIdsCampanias.includes(campId)) {
            cb.checked = true;
            const subPanel = document.getElementById(`tiendas-campania-panel-${campId}`);
            if (subPanel) {
                subPanel.style.display = 'block';
                // Activamos sus tiendas
                const tiendasAsignadas = misIdsTiendasMap[campId] || [];
                subPanel.querySelectorAll('.check-tienda-sub').forEach(tcb => {
                    tcb.checked = tiendasAsignadas.includes(parseInt(tcb.value));
                });
            }
        }
    });

    const tbody = document.getElementById('tabla-contactos-dinamica');
    tbody.innerHTML = ''; 
    if (colab.responsables && colab.responsables.length > 0) {
        colab.responsables.forEach((resp, index) => renderizarBloqueContacto(resp, index, false));
    } else {
        renderizarBloqueContacto({}, 0, false);
    }

    // 🌟 AL NO HABER ERRORES ARRIBA, ESTAS LÍNEAS SE EJECUTARÁN PERFECTAMENTE
    document.getElementById('edit-zona').value = colab.zonaNombre || "";
    const checkCapital = document.getElementById('check-es-capital-panel');
    checkCapital.checked = colab.esCapital || false;
    
    const divDistrito = document.getElementById('campo-distrito-panel');
    if (colab.esCapital) {
        divDistrito.style.display = 'flex';
        document.getElementById('edit-distrito').value = colab.distritoNombre || "";
    } else {
        divDistrito.style.display = 'none';
    }

    checkCapital.onchange = function() {
        divDistrito.style.display = this.checked ? 'flex' : 'none';
    };
}

function renderizarBloqueContacto(resp, index = null, esNuevo = false) {
    const tbody = document.getElementById('tabla-contactos-dinamica');
    const currIndex = index !== null ? index : (tbody.querySelectorAll('.contacto-header').length);
    const form = document.getElementById('form-edicion-lateral');
    const estaEnEdicion = form.classList.contains('modo-edicion');
    
    const disabledAtr = estaEnEdicion ? '' : 'disabled';
    const readonlyAtr = estaEnEdicion ? '' : 'readonly';
    const rowspan = esNuevo ? 5 : 3;

    let html = `
        <tr class="contacto-header">
            <td rowspan="${rowspan}" style="width: 90px; text-align: center; vertical-align: top; background-color: #f8fafc;">
                <strong style="color: #1e3a8a;">Contacto ${currIndex + 1}</strong><br>
                <label style="cursor: pointer; display: inline-block; margin-top: 8px;">
                    <span style="color: #dc2626; font-size: 12px; display: block; margin-bottom: 2px;">Principal</span>
                    <input type="radio" name="radio-principal" class="check-inline r-principal" ${resp.esPrincipal ? 'checked' : ''} ${disabledAtr}>
                </label>
                <button type="button" class="btn-eliminar-contacto" onclick="eliminarContacto(this)" style="${estaEnEdicion ? 'display:block;' : 'display:none;'} color:red; margin-top:10px; cursor:pointer; width: 100%; border: none; background: none; font-size: 12px;">🗑️ Borrar</button>
            </td>
            <td><span class="etiqueta-tabla">Nombre</span> <input type="text" class="input-linea r-nombre" value="${resp.nombre || ''}" ${readonlyAtr}></td>
        </tr>
        <tr><td><span class="etiqueta-tabla">Email</span> <input type="email" class="input-linea r-email" value="${resp.email || ''}" ${readonlyAtr}></td></tr>
        <tr><td><span class="etiqueta-tabla">Telef.</span> <input type="tel" class="input-linea r-telefono" value="${resp.telefono || ''}" ${readonlyAtr}></td></tr>
    `;

    if (esNuevo) {
        html += `
            <tr><td><span class="etiqueta-tabla">Usuario</span> <input type="text" class="input-linea r-user" placeholder="Login (email)" required></td></tr>
            <tr><td><span class="etiqueta-tabla">Contraseña</span> <input type="password" class="input-linea r-pass" placeholder="Contraseña" required></td></tr>
        `;
    }
    tbody.insertAdjacentHTML('beforeend', html);
}

window.eliminarContacto = function(btn) {
    const trPrincipal = btn.closest('tr');
    const filasABorrar = parseInt(trPrincipal.querySelector('td').rowSpan);
    let filaActual = trPrincipal;
    for (let i = 0; i < filasABorrar; i++) {
        let siguienteFila = filaActual.nextElementSibling;
        filaActual.remove();
        filaActual = siguienteFila;
    }
}

async function guardarCambiosReales(e) {
    e.preventDefault();
    
    const idEntidad = document.getElementById('colaborador-id').value;
    const responsables = [];
    
    document.querySelectorAll('.contacto-header').forEach(filaPrincipal => {
        const email = filaPrincipal.nextElementSibling.querySelector('.r-email').value.trim();
        const telefono = filaPrincipal.nextElementSibling.nextElementSibling.querySelector('.r-telefono').value.trim();
        
        const respObj = {
            nombre: filaPrincipal.querySelector('.r-nombre').value.trim().toUpperCase(),
            email: email,
            telefono: telefono,
            esPrincipal: filaPrincipal.querySelector('.r-principal').checked
        };

        const rowUser = filaPrincipal.nextElementSibling.nextElementSibling.nextElementSibling;
        if (rowUser && rowUser.querySelector('.r-user')) {
            respObj.username = rowUser.querySelector('.r-user').value.trim();
            respObj.password = rowUser.nextElementSibling.querySelector('.r-pass').value;
        }
        responsables.push(respObj);
    });

    const idsCampaniasActualizadas = [];
    const tiendasPorCampaniaActualizadas = {};

    document.querySelectorAll('.check-campania-master:checked').forEach(cb => {
        const campId = parseInt(cb.value);
        idsCampaniasActualizadas.push(campId);

        const subPanel = document.getElementById(`tiendas-campania-panel-${campId}`);
        if (subPanel) {
            const checksTiendas = subPanel.querySelectorAll('.check-tienda-sub:checked');
            tiendasPorCampaniaActualizadas[campId] = Array.from(checksTiendas).map(tcb => parseInt(tcb.value));
        }
    });

    const objetoUpdate = {
        nombre: document.getElementById('titulo-colaborador').value.trim().toUpperCase(),
        estadoActivo: document.getElementById('check-campania').checked,
        observaciones: document.getElementById('edit-observaciones').value.trim(),
        calle: document.getElementById('edit-calle').value.trim().toUpperCase(),
        numero: parseInt(document.getElementById('edit-numero').value),
        nombreLocalidad: document.getElementById('edit-localidad').value.trim().toUpperCase(),
        numeroCP: document.getElementById('edit-cp').value.trim(),
        nombreZonaGeografica: (document.getElementById('edit-zona').value || "").trim().toUpperCase() || null,
        esCapital: document.getElementById('check-es-capital-panel').checked,
        nombreDistrito: (document.getElementById('edit-distrito').value || "").trim().toUpperCase() || null,
        idsCampanias: idsCampaniasActualizadas,
        tiendasPorCampania: tiendasPorCampaniaActualizadas,
        responsables: responsables
    };

    try {
        await apiService.actualizarEntidad(idEntidad, objetoUpdate);

        const colabLocal = JSON.parse(sessionStorage.getItem("colaboradorSeleccionado"));
        const nuevoColab = { ...colabLocal, ...objetoUpdate };
        
        nuevoColab.localidadNombre = objetoUpdate.nombreLocalidad;
        nuevoColab.zonaNombre = objetoUpdate.nombreZonaGeografica;
        nuevoColab.distritoNombre = objetoUpdate.nombreDistrito;
        nuevoColab.codigoPostal = objetoUpdate.numeroCP;

        sessionStorage.setItem("colaboradorSeleccionado", JSON.stringify(nuevoColab));

        alert("✅ Colaborador actualizado correctamente");
        
        canalComunicacion.postMessage('recargar-tabla');
        toggleModoEdicion();
        
    } catch (error) {
        // 🌟 CAZAMOS TAMBIÉN AQUÍ LAS VALIDACIONES CONTROLADAS EN LA EDICIÓN:
        if (error.message && (error.message.includes("Este teléfono ya está asociado") || error.message.includes("Contacto_telefono_key"))) {
            alert("⚠️ Este teléfono ya está asociado a otro usuario");
        } else if (error.message && error.message.includes("dirección a la que la has asociado ya existe")) {
            alert("⚠️ No puedes actualizar a esta dirección porque ya está asignada a otra entidad");
        } else {
            alert("❌ Error al actualizar: " + error.message);
        }
    }
}

function obtenerChecksMarcados(idContenedor) {
    const contenedor = document.getElementById(idContenedor);
    const checks = contenedor.querySelectorAll('input[type="checkbox"]:checked');
    return Array.from(checks).map(cb => parseInt(cb.value));
}

function cerrarPanelLateral() {
    if (window.parent) {
        const iframeMenu = window.parent.document.querySelector('.menu-lateral-iframe');
        if (iframeMenu) iframeMenu.src = '../MenuLateral/menu-lateral.html';
        
        // 🌟 DOBLE BLINDAJE INTER-FRAME: Emitimos por canal de radio y por mensaje de ventana jerárquico
        canalComunicacion.postMessage('resetear-boton-modificar');
        window.parent.postMessage('resetear-boton-modificar', '*');
    }
}