/**
 * CONEXIÓN A API SEPARADA DE LA LÓGICA
 */


// Url base
const API_BASE = "http://localhost:8080/api";

/**
 * Función para realizar un fetch sobre algo específico
 * 
 * - endpoint: extensión sobre la instancia a la que le realizaremos el feth
 * - opciones: parámetros adicionales para el feth (por defecto no son necesarios) - DELETE
 */
async function peticionFecth(endpoint, opciones = {}) {
    try {

        // Intentamos hacer un fetch a la API con el endPoint correspondiente
        const res = await fetch(`${API_BASE}${endpoint}`, opciones);
        
        // Si hay algún fallo en la solicitud (
        // 400 - Json mal formateado, 
        // 401 - No autorizado, 
        // 403 - Prohibido, 
        // 404 - No encontrado
        // )
        if (!res.ok) {
            const errorText = await res.text();

            // Mostramos el tipo de error
            throw new Error(errorText || `Error HTTP: ${res.status}`);
        }
        
        // Si la petición es eliminar un objeto, no continuamos
        if (opciones.method === 'DELETE') return true;
        
        // Obtenemos el formato en el que están los datos (lo devuelve la cabecera)
        const contentType = res.headers.get("content-type");

        // Si hemos podido obtener el tipo de formato y está en formato JSON
        if (contentType && contentType.includes("application/json")) {
            // Pasamos la respuesta a JSON
            return await res.json();
        }
        // En caso contrario 
        else 
        {
            // Pasamos la respuesta a texto plano
            return await res.text();
        }
    } 
    // Si hay algún otro error (no es por parte del cliente)
    catch (error) 
    {
        // Mostramos el endpoint que ha podido dar error (en la consola)
        console.error(`ERROR: Error en la API (${endpoint}):`, error);
        // Propagamos el error para que la vista decida qué hacer
        throw error; 
    }
}

/**
 * Métodos exportados
 */

export const apiService = {
    // Para las entidades colaboradoras
    obtenerEntidades: () => peticionFecth('/entidades'),
    
    eliminarEntidad: (id) => peticionFecth(`/entidades/${id}`, { method: 'DELETE' }),
    
    actualizarEntidad: (id, data) => peticionFecth(`/entidades/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }),

    crearEntidad: (data) => peticionFecth('/entidades/registro', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }),

    // Para las campañas 
    obtenerCampanias: () => peticionFecth('/campanias'),

    // Datos maestros(Desplegables, Códigos Postales, etc.)
    obtenerCodigosPostales: () => peticionFecth('/codigos-postales'),
    obtenerLocalidades: () => peticionFecth('/localidades'),
    obtenerTiendas: () => peticionFecth('/tiendas'),
    obtenerZonasGeograficas: () => peticionFecth('/zonas-geograficas'),
    obtenerDistritos: () => peticionFecth('/distritos'),
    obtenerDirecciones: () => peticionFecth('/direcciones'),
    obtenerCoordinadores: () => peticionFecth('/coordinadores')
};