import { apiService } from './apiService.js';
import { canalComunicacion } from './utils.js';

// Estado local de este componente
let idCampaniaVisualizada = 1; 

document.addEventListener('DOMContentLoaded', () => {
    const btnSeleccionarCampania = document.querySelector('.cambiar-campania button');
    const btnCerrarSelector = document.getElementById('cerrar-selector');

    if (btnSeleccionarCampania) btnSeleccionarCampania.onclick = abrirSelectorCampanias;
    if (btnCerrarSelector) btnCerrarSelector.onclick = () => document.getElementById('modal-campanias').style.display = 'none';
});

// selectorCampanias.js -> Reemplaza la función abrirSelectorCampanias
async function abrirSelectorCampanias() {
    try {
        // 🔄 Pedimos las campañas al servicio
        const campanias = await apiService.obtenerCampanias();

        // 🌟 SINCRONIZACIÓN: Leemos la memoria RAM externa antes de pintar las tarjetas
        const guardada = localStorage.getItem("idCampaniaVisualizada");
        if (guardada) {
            idCampaniaVisualizada = parseInt(guardada);
        } else if (campanias.length > 0) {
            const campaniaActiva = campanias.find(c => c.activa === true) || campanias[0];
            idCampaniaVisualizada = campaniaActiva.id;
        }

        const grid = document.getElementById('lista-campanias');
        grid.innerHTML = ''; 
        document.getElementById('modal-campanias').style.display = 'flex';

        campanias.forEach(c => {
            const esSeleccionada = c.id === idCampaniaVisualizada;
            const card = document.createElement('div');
            card.className = `campania-card ${esSeleccionada ? 'seleccionada' : ''} ${c.activa ? 'es-activa' : 'es-inactiva'}`;
            
            const inicio = new Date(c.fechaInicio).toLocaleDateString();
            const fin = new Date(c.fechaFin).toLocaleDateString();
            
            // 🌟 INYECTAMOS INLINE EL SEGURO CONTRA ROTURAS (white-space: nowrap)
            const labelActiva = c.activa 
                ? '<span class="badge badge-activa" style="white-space: nowrap; display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold;">ACTIVA</span>' 
                : '<span class="badge badge-inactiva" style="white-space: nowrap; display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold;">INACTIVA</span>';
            
            const labelSeleccionada = esSeleccionada 
                ? '<span class="badge badge-viendo" style="white-space: nowrap; display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; margin-left: 5px;">VIENDO AHORA</span>' 
                : '';

            // Maquetamos la cabecera interna con un flex dinámico que respeta el espacio de los badges
            card.innerHTML = `
                <div class="card-header-flex" style="display: flex; justify-content: space-between; align-items: center; width: 100%; gap: 10px; margin-bottom: 8px;">
                    <h3 style="margin: 0; font-size: 1.1em; color: #1e3a8a; text-align: left;">${c.nombre}</h3>
                    <div class="badges-container" style="display: flex; align-items: center; flex-shrink: 0;">
                        ${labelActiva}
                        ${labelSeleccionada}
                    </div>
                </div>
                <p><strong>Inicio:</strong> ${inicio} | <strong>Fin:</strong> ${fin}</p>
                <p class="anio-info" style="margin-top: 5px; font-size: 0.85em; color: #64748b;">Año fiscal: ${c.anio}</p>
            `;

            card.onclick = () => {
                idCampaniaVisualizada = c.id; 
                seleccionarCampania(c);
            };
            grid.appendChild(card);
        });
    } catch (error) {
        console.error("🚨 Error en el selector de campañas:", error);
    }
}

// selectorCampanias.js -> Nueva función final
function seleccionarCampania(campania) {
    document.getElementById('modal-campanias').style.display = 'none';
    
    // 🌟 PUENTE DIRECTO: Si estamos en la misma ventana, llamamos al método manual inmediatamente
    if (typeof window.cambiarCampaniaManual === 'function') {
        window.cambiarCampaniaManual(campania);
    }
    
    // 📢 Mantenemos el mensaje por si otros frames externos (como los filtros) están a la escucha
    canalComunicacion.postMessage({ 
        type: 'cambiar-campania', 
        campania: campania 
    });
}