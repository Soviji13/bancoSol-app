package com.bancosol.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "\"Cadena\"", schema = "public")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Cadena {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String nombre;

    @Column(nullable = false, unique = true)
    private String codigo;

    // Regla de Negocio: Mayúsculas siempre
    @PrePersist @PreUpdate
    private void asegurarMayusculas() {
        if (this.nombre != null) this.nombre = this.nombre.toUpperCase();
        if (this.codigo != null) this.codigo = this.codigo.toUpperCase();
    }

    //Refactorización de Cadena
    @ManyToMany(mappedBy = "cadenas")
    private List<Campania> campanias = new ArrayList<>();
}